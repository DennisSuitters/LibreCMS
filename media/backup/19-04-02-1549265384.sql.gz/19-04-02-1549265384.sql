DROP TABLE IF EXISTS `cart`;

CREATE TABLE IF NOT EXISTS `cart` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `iid` bigint(20) unsigned NOT NULL,
  `cid` bigint(20) NOT NULL,
  `rid` bigint(20) NOT NULL,
  `quantity` mediumint(20) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `si` varchar(128) COLLATE utf8_bin NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- ------------------------------------------------ 

DROP TABLE IF EXISTS `choices`;

CREATE TABLE IF NOT EXISTS `choices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `rid` bigint(20) unsigned NOT NULL,
  `contentType` varchar(16) COLLATE utf8_bin NOT NULL,
  `rank` int(4) unsigned NOT NULL,
  `icon` varchar(64) COLLATE utf8_bin NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `title` varchar(60) COLLATE utf8_bin NOT NULL,
  `value` int(4) NOT NULL,
  `tis` int(10) NOT NULL,
  `tie` int(10) NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `choices` (id, uid, rid, contentType, rank, icon, url, title, value, tis, tie, ti) VALUES
	(1,1,0,`bio_skills`,0,``,``,`PHP`,90,0,0,0),
	(2,1,0,`bio_skills`,0,``,``,`HTML`,95,0,0,0),
	(3,0,0,`social`,0,`facebook`,`https://www.facebook.com/diemendesign/`,``,0,0,0,0),
	(11,1,0,`social`,0,`facebook`,`https://www.facebook.com/diemendesign/`,``,0,0,0,0),
	(13,1,0,`social`,0,`youtube`,`https://www.youtube.com/channel/UCTx4a5pEpU1VB0USpPAs7TQ`,``,0,0,0,0),
	(15,0,0,`social`,0,`youtube`,`https://www.youtube.com/channel/UCTx4a5pEpU1VB0USpPAs7TQ`,``,0,0,0,0);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `comments`;

CREATE TABLE IF NOT EXISTS `comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contentType` varchar(16) COLLATE utf8_bin NOT NULL,
  `rid` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `cid` bigint(20) unsigned NOT NULL,
  `ip` varchar(20) COLLATE utf8_bin NOT NULL,
  `avatar` tinytext COLLATE utf8_bin NOT NULL,
  `gravatar` tinytext COLLATE utf8_bin NOT NULL,
  `email` varchar(60) COLLATE utf8_bin NOT NULL,
  `name` varchar(40) COLLATE utf8_bin NOT NULL,
  `notes` text COLLATE utf8_bin NOT NULL,
  `status` varchar(16) COLLATE utf8_bin NOT NULL,
  `active` tinyint(1) unsigned NOT NULL,
  `tie` int(10) NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `comments` (id, contentType, rid, uid, cid, ip, avatar, gravatar, email, name, notes, status, active, tie, ti) VALUES
	(3,`article`,10,1,0,`127.0.0.1`,``,``,`dennis@studiojunkyard.com`,`Kenika Suitters`,`another test`,`approved`,0,0,1541839426),
	(4,`article`,10,1,0,`127.0.0.1`,``,``,`dennis@studiojunkyard.com`,`Kenika Suitters`,`fsadf`,`approved`,0,0,1541839660),
	(5,`article`,10,1,0,`127.0.0.1`,``,``,`dennis@studiojunkyard.com`,`Kenika Suitters`,`fsadf`,`approved`,0,0,1541839667),
	(6,`article`,10,1,0,`127.0.0.1`,``,``,`dennis@studiojunkyard.com`,`Kenika Suitters`,`asdf`,`approved`,0,0,1541839891),
	(7,`article`,10,1,0,`127.0.0.1`,``,``,`dennis@studiojunkyard.com`,`Kenika Suitters`,`awdgedfgeagf`,`approved`,0,0,1541840029),
	(8,`article`,10,1,0,`127.0.0.1`,``,``,`dennis@studiojunkyard.com`,`Kenika Suitters`,`awdgedfgeagf`,`approved`,0,0,1541840159);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `config`;

CREATE TABLE IF NOT EXISTS `config` (
  `id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,
  `development` int(1) NOT NULL,
  `maintenance` int(1) NOT NULL,
  `comingsoon` int(1) NOT NULL,
  `options` varchar(32) COLLATE utf8_bin NOT NULL,
  `theme` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoTitle` varchar(60) COLLATE utf8_bin NOT NULL,
  `seoDescription` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoCaption` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoKeywords` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoRSSTitle` tinytext COLLATE utf8_bin NOT NULL,
  `seoRSSNotes` text COLLATE utf8_bin NOT NULL,
  `seoRSSLink` varchar(256) COLLATE utf8_bin NOT NULL,
  `seoRSSAuthor` tinytext COLLATE utf8_bin NOT NULL,
  `seoRSSti` bigint(20) NOT NULL,
  `business` varchar(40) COLLATE utf8_bin NOT NULL,
  `abn` varchar(32) COLLATE utf8_bin NOT NULL,
  `address` varchar(80) COLLATE utf8_bin NOT NULL,
  `suburb` varchar(40) COLLATE utf8_bin NOT NULL,
  `city` varchar(40) COLLATE utf8_bin NOT NULL,
  `state` varchar(40) COLLATE utf8_bin NOT NULL,
  `country` varchar(40) COLLATE utf8_bin NOT NULL,
  `postcode` mediumint(5) unsigned NOT NULL,
  `phone` varchar(14) COLLATE utf8_bin NOT NULL,
  `mobile` varchar(14) COLLATE utf8_bin NOT NULL,
  `email` varchar(60) COLLATE utf8_bin NOT NULL,
  `vti` int(10) unsigned NOT NULL,
  `sti` int(10) unsigned NOT NULL,
  `dateFormat` varchar(64) COLLATE utf8_bin NOT NULL,
  `email_check` int(10) NOT NULL,
  `email_interval` int(10) NOT NULL,
  `language` varchar(8) COLLATE utf8_bin NOT NULL,
  `timezone` varchar(128) COLLATE utf8_bin NOT NULL,
  `orderPayti` int(10) unsigned NOT NULL,
  `orderEmailSubject` tinytext COLLATE utf8_bin NOT NULL,
  `orderEmailLayout` text COLLATE utf8_bin NOT NULL,
  `orderEmailNotes` text COLLATE utf8_bin NOT NULL,
  `orderEmailReadNotification` tinyint(1) NOT NULL,
  `passwordResetLayout` text COLLATE utf8_bin NOT NULL,
  `passwordResetSubject` tinytext COLLATE utf8_bin NOT NULL,
  `accountActivationSubject` tinytext COLLATE utf8_bin NOT NULL,
  `accountActivationLayout` text COLLATE utf8_bin NOT NULL,
  `bookingEmailSubject` tinytext COLLATE utf8_bin NOT NULL,
  `bookingEmailLayout` text COLLATE utf8_bin NOT NULL,
  `bookingEmailReadNotification` tinyint(1) NOT NULL,
  `bookingAutoReplySubject` tinytext COLLATE utf8_bin NOT NULL,
  `bookingAutoReplyLayout` text COLLATE utf8_bin NOT NULL,
  `bookingAttachment` varchar(255) COLLATE utf8_bin NOT NULL,
  `contactAutoReplySubject` tinytext COLLATE utf8_bin NOT NULL,
  `contactAutoReplyLayout` text COLLATE utf8_bin NOT NULL,
  `newslettersEmbedImages` int(1) NOT NULL,
  `newslettersSendMax` int(4) NOT NULL,
  `newslettersSendDelay` int(4) NOT NULL,
  `newslettersOptOutLayout` text COLLATE utf8_bin NOT NULL,
  `bank` varchar(60) COLLATE utf8_bin NOT NULL,
  `bankAccountName` varchar(40) COLLATE utf8_bin NOT NULL,
  `bankAccountNumber` varchar(40) COLLATE utf8_bin NOT NULL,
  `bankBSB` varchar(16) COLLATE utf8_bin NOT NULL,
  `bankPayPal` varchar(60) COLLATE utf8_bin NOT NULL,
  `showItems` int(4) NOT NULL,
  `idleTime` int(6) NOT NULL,
  `git_commits` longblob NOT NULL,
  `git_ti` int(10) NOT NULL,
  `ga_clientID` varchar(128) COLLATE utf8_bin NOT NULL,
  `ga_tracking` text COLLATE utf8_bin NOT NULL,
  `ga_verification` tinytext COLLATE utf8_bin NOT NULL,
  `seo_msvalidate` tinytext COLLATE utf8_bin NOT NULL,
  `seo_yandexverification` tinytext COLLATE utf8_bin NOT NULL,
  `seo_alexaverification` tinytext COLLATE utf8_bin NOT NULL,
  `seo_domainverify` tinytext COLLATE utf8_bin NOT NULL,
  `geo_region` tinytext COLLATE utf8_bin NOT NULL,
  `geo_placename` tinytext COLLATE utf8_bin NOT NULL,
  `geo_position` tinytext COLLATE utf8_bin NOT NULL,
  `php_options` varchar(16) COLLATE utf8_bin NOT NULL,
  `php_APIkey` varchar(255) COLLATE utf8_bin NOT NULL,
  `php_honeypot` tinytext COLLATE utf8_bin NOT NULL,
  `php_quicklink` tinytext COLLATE utf8_bin NOT NULL,
  `spamfilter` varchar(8) COLLATE utf8_bin NOT NULL,
  `notification_volume` int(4) NOT NULL,
  `mediaMaxWidth` int(4) NOT NULL,
  `mediaMaxHeight` int(4) NOT NULL,
  `mediaMaxWidthThumb` int(4) NOT NULL,
  `mediaMaxHeightThumb` int(4) NOT NULL,
  `mediaQuality` int(2) NOT NULL,
  `suggestions` int(1) NOT NULL,
  `bti` int(10) unsigned NOT NULL,
  `backup_ti` int(10) NOT NULL,
  `uti` int(10) NOT NULL,
  `uti_freq` int(10) NOT NULL,
  `update_url` varchar(255) COLLATE utf8_bin NOT NULL,
  `navstat` int(4) NOT NULL,
  `iconsColor` int(1) NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `config` (id, development, maintenance, comingsoon, options, theme, seoTitle, seoDescription, seoCaption, seoKeywords, seoRSSTitle, seoRSSNotes, seoRSSLink, seoRSSAuthor, seoRSSti, business, abn, address, suburb, city, state, country, postcode, phone, mobile, email, vti, sti, dateFormat, email_check, email_interval, language, timezone, orderPayti, orderEmailSubject, orderEmailLayout, orderEmailNotes, orderEmailReadNotification, passwordResetLayout, passwordResetSubject, accountActivationSubject, accountActivationLayout, bookingEmailSubject, bookingEmailLayout, bookingEmailReadNotification, bookingAutoReplySubject, bookingAutoReplyLayout, bookingAttachment, contactAutoReplySubject, contactAutoReplyLayout, newslettersEmbedImages, newslettersSendMax, newslettersSendDelay, newslettersOptOutLayout, bank, bankAccountName, bankAccountNumber, bankBSB, bankPayPal, showItems, idleTime, git_commits, git_ti, ga_clientID, ga_tracking, ga_verification, seo_msvalidate, seo_yandexverification, seo_alexaverification, seo_domainverify, geo_region, geo_placename, geo_position, php_options, php_APIkey, php_honeypot, php_quicklink, spamfilter, notification_volume, mediaMaxWidth, mediaMaxHeight, mediaMaxWidthThumb, mediaMaxHeightThumb, mediaQuality, suggestions, bti, backup_ti, uti, uti_freq, update_url, navstat, iconsColor, ti) VALUES
	(1,1,0,0,`1111111111000000`,`bizzyknits`,`Default Template for LibreCMS (Title)`,`Default Template for LibreCMS based on Bootstrap 4 (Description) This can be edited in Administration under Preferences, SEO Tab, in the SEO Description box.`,`Default Template for LibreCMS based on Bootstrap 4 (Caption)`,`librecms,bootstrap,php,mysql`,``,``,``,``,0,`Default`,`000 000 000`,`666 Nowhere Rd`,`Anywhere`,`Paradise`,`Tasmania`,`Australia`,6666,`61 00 000 000`,`0000 000 000`,`info@studiojunkyard.com`,0,3600,`M jS, Y g:i A`,1425893894,3600,`en-AU`,`Australia/Hobart`,1209600,``,`<p>Hello {first},</p> <p>Please find attached Order {order_number}</p> <p>Note: {notes}</p>`,`%3Cp%3EServices%20are%20considered%20to%20be%20in%20a%20%3Cb%3EGrace%20Period%3C/b%3E%20for%20a%20total%20of%20%3Cb%3E14%20days%3C/b%3E%20whilst%20this%20invoice%20is%20outstanding.%20If%20no%20payment%20or%20contact%20to%20make%20payment%20arrangements%20has%20been%20forthcoming%20during%20the%20%3Cb%3E14%20Day%20Grace%20Period%3C/b%3E%2C%20any%20unpaid%20accounts%20will%20be%20%3Cb%3Esuspended%3C/b%3E%2C%20unless%20other%20arrangements%20have%20been%20made%20by%20contacting%20us%20%28Details%20at%20the%20top%20of%20the%20Invoice%29.%20If%20%3Cb%3E30%20days%3C/b%3E%20without%20payment%20or%20contact%20has%20lapsed%2C%20we%20will%20%3Cb%3Eat%20our%20discretion%3C/b%3E%20consider%20%3Cb%3Eterminating%3C/b%3E%20services%2C%20upon%20which%20you%20will%20be%20charged%20for%20the%20following%20full%20month%20as%20a%20termination%20fee.%20Following%20another%2030%20days%20%2860%20days%20or%202%20months%29%20from%20this%20Order%20Date%2C%20if%20no%20contact%20or%20resolution%20has%20been%20settled%2C%20we%20will%20remove/delete%20any%20data%20from%20our%20servers%20at%20our%20discretion.%3C/p%3E`,0,`%3Cp%3EHi%20%7Bname%7D%2C%3C/p%3E%3Cp%3EA%20Password%20Reset%20was%20requested%2C%20it%20is%20now%3A%20%7Bpassword%7D%3C/p%3E%3Cp%3EWe%20recommend%20changing%20the%20above%20password%20after%20logging%20in.%3C/p%3E`,`Password Reset {business}`,`Account Activation for {username} from {site}.`,`<p>Hi {username},</p><p>Below is the Activation Link to enable your Account at {site}.<br>{activation_link}</p><p>If this email is in error, and you did not sign up for an Account, please take the time to contact us to let us know, or alternatively ignore this email and your email will be purged from our system in a few days.</p>`,`{business} Booking Confirmation on {date}`,`<p>Hi {first},</p><p>{details}</p><p>Please check the details above, and get in touch if any need correcting.</p><p>Kind Regards,<br>{business}<br></p>`,0,`{business} Booking Confirmation on {date}`,`%3Cp%3EHi%20%7Bfirst%7D%2C%3C/p%3E%3Cp%3EThank%20you%20for%20contacting%20%7Bbusiness%7D%2C%20someone%20will%20get%20back%20to%20you%20ASAP.%3Cbr%3EPlease%20note%2C%20this%20email%20is%20not%20a%20confirmed%20booking%20-%20we%20will%20contact%20you%20to%20confirm%20the%20time%20and%20date%20of%20your%20booking.%3Cbr%3E%3C/p%3E%3Cp%3EKind%20Regards%2C%3Cbr%3E%7Bbusiness%7D%3Cbr%3E%3C/p%3E`,``,`{business} Contact Confirmation on {date}`,`<p>Hi {first},</p><p>Thank you for contacting {business}, someone will get back to you ASAP.</p><p>Kind Regards,</p><p>{business}</p><p><br></p>`,0,50,5,`<br>
<br>
<p><span style=\"font-size: 10px;\">If you don\'t wish to continue to receive these Newsletters you can <a href=\"{optOutLink}\">Unsubscribe</a>.</span></p>`,`ConYaWealth`,`Default`,`0000 0000 0000 0000`,`0000 0000`,``,4,10,`[{\"sha\":\"64d45a55cbb0c754da2361998091a75e5ab0bf73\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-19T13:21:08Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-19T13:21:08Z\"},\"message\":\"Fix CodeMirror loading Cached files, Fix Testiminal Avatar Alt, Fix Code Input not displaying.\",\"tree\":{\"sha\":\"1cb316e01fdee3fb6b6de554bcb7dc6c60356c6c\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/1cb316e01fdee3fb6b6de554bcb7dc6c60356c6c\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/64d45a55cbb0c754da2361998091a75e5ab0bf73\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/64d45a55cbb0c754da2361998091a75e5ab0bf73\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/64d45a55cbb0c754da2361998091a75e5ab0bf73\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/64d45a55cbb0c754da2361998091a75e5ab0bf73/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"e936cc90e93bf947714837bb27491fa681076c19\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/e936cc90e93bf947714837bb27491fa681076c19\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/e936cc90e93bf947714837bb27491fa681076c19\"}]},{\"sha\":\"e936cc90e93bf947714837bb27491fa681076c19\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-18T08:52:01Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-18T08:52:01Z\"},\"message\":\"Fix Bookings not selecting Booking, Fix rendering of Testimonials\",\"tree\":{\"sha\":\"aeda9e5d3210a5704e467385be6e8019249bc55d\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/aeda9e5d3210a5704e467385be6e8019249bc55d\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/e936cc90e93bf947714837bb27491fa681076c19\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/e936cc90e93bf947714837bb27491fa681076c19\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/e936cc90e93bf947714837bb27491fa681076c19\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/e936cc90e93bf947714837bb27491fa681076c19/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"32043110458aa9191c2579ffee18717fee120d93\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/32043110458aa9191c2579ffee18717fee120d93\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/32043110458aa9191c2579ffee18717fee120d93\"}]},{\"sha\":\"32043110458aa9191c2579ffee18717fee120d93\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-15T06:06:54Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-15T06:06:54Z\"},\"message\":\"Fix Date Format, Fix Avatars for Testimonials\",\"tree\":{\"sha\":\"c4f4c8135de599595c10d7cf5eca226575cc9ad1\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/c4f4c8135de599595c10d7cf5eca226575cc9ad1\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/32043110458aa9191c2579ffee18717fee120d93\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/32043110458aa9191c2579ffee18717fee120d93\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/32043110458aa9191c2579ffee18717fee120d93\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/32043110458aa9191c2579ffee18717fee120d93/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25\"}]},{\"sha\":\"0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-14T09:51:49Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-14T09:51:49Z\"},\"message\":\"Some Fixes, most of which I forget\",\"tree\":{\"sha\":\"5a1d878c746e7c568cfdd7bbdc622339287bb0c1\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/5a1d878c746e7c568cfdd7bbdc622339287bb0c1\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/0fdd0eb5a3b65200a6c4c1d723dfb8b47e1d3a25/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"cf2bd8f2478c1ae916a3f37fe8554fe529721cfa\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cf2bd8f2478c1ae916a3f37fe8554fe529721cfa\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/cf2bd8f2478c1ae916a3f37fe8554fe529721cfa\"}]},{\"sha\":\"cf2bd8f2478c1ae916a3f37fe8554fe529721cfa\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-07T15:32:31Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-07T15:32:31Z\"},\"message\":\"Fix Admin Checkbox Styling, Add CodeMirror Theme Template Editing\",\"tree\":{\"sha\":\"983c31119318b4acb851be9fab2736566e1842f9\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/983c31119318b4acb851be9fab2736566e1842f9\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/cf2bd8f2478c1ae916a3f37fe8554fe529721cfa\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cf2bd8f2478c1ae916a3f37fe8554fe529721cfa\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/cf2bd8f2478c1ae916a3f37fe8554fe529721cfa\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cf2bd8f2478c1ae916a3f37fe8554fe529721cfa/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"a531d6efa6da0f9204107482fce82990aa506516\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/a531d6efa6da0f9204107482fce82990aa506516\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/a531d6efa6da0f9204107482fce82990aa506516\"}]},{\"sha\":\"a531d6efa6da0f9204107482fce82990aa506516\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-07T15:27:38Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-07-07T15:27:38Z\"},\"message\":\"Fix Admin Checkbox Styling, Add CodeMirror Theme Template Editing\",\"tree\":{\"sha\":\"f1bd09ae6c7f51fb3c4e50118b8d5282f854d8cb\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/f1bd09ae6c7f51fb3c4e50118b8d5282f854d8cb\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/a531d6efa6da0f9204107482fce82990aa506516\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/a531d6efa6da0f9204107482fce82990aa506516\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/a531d6efa6da0f9204107482fce82990aa506516\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/a531d6efa6da0f9204107482fce82990aa506516/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911\"}]},{\"sha\":\"2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-28T15:50:49Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-28T15:50:49Z\"},\"message\":\"Added more MicroFormat Markup and Parsing\",\"tree\":{\"sha\":\"fe1f66991d1236822c27772408cde48b2bf2b089\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/fe1f66991d1236822c27772408cde48b2bf2b089\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/2df8cd5da7f8ccc92e4de7cc9c10ff3c5733d911/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"7b9232793cc92369656d08e5b9d6377aeee534f7\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/7b9232793cc92369656d08e5b9d6377aeee534f7\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/7b9232793cc92369656d08e5b9d6377aeee534f7\"}]},{\"sha\":\"7b9232793cc92369656d08e5b9d6377aeee534f7\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T16:09:40Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T16:09:40Z\"},\"message\":\"Add Review and Testimonial Functionality\",\"tree\":{\"sha\":\"9068f40d350fed6b658adeeae47f395549f84f95\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/9068f40d350fed6b658adeeae47f395549f84f95\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/7b9232793cc92369656d08e5b9d6377aeee534f7\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/7b9232793cc92369656d08e5b9d6377aeee534f7\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/7b9232793cc92369656d08e5b9d6377aeee534f7\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/7b9232793cc92369656d08e5b9d6377aeee534f7/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"ff95b3baecee545c59c830f2c58fc036656da425\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/ff95b3baecee545c59c830f2c58fc036656da425\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/ff95b3baecee545c59c830f2c58fc036656da425\"}]},{\"sha\":\"ff95b3baecee545c59c830f2c58fc036656da425\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T16:09:18Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T16:09:18Z\"},\"message\":\"Add Review and Testimonial Functionality\",\"tree\":{\"sha\":\"0f105017f0683af7226cda65399a05dd73f6d962\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/0f105017f0683af7226cda65399a05dd73f6d962\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/ff95b3baecee545c59c830f2c58fc036656da425\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/ff95b3baecee545c59c830f2c58fc036656da425\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/ff95b3baecee545c59c830f2c58fc036656da425\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/ff95b3baecee545c59c830f2c58fc036656da425/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"cfe3ffc378b1abbe4951444c20897a84bfad08ef\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cfe3ffc378b1abbe4951444c20897a84bfad08ef\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/cfe3ffc378b1abbe4951444c20897a84bfad08ef\"}]},{\"sha\":\"cfe3ffc378b1abbe4951444c20897a84bfad08ef\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T15:24:24Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T15:24:24Z\"},\"message\":\"Add Review and Testimonial Functionality\",\"tree\":{\"sha\":\"5d05fac79c5cd4148f25ead732079a037a76ae90\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/5d05fac79c5cd4148f25ead732079a037a76ae90\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/cfe3ffc378b1abbe4951444c20897a84bfad08ef\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cfe3ffc378b1abbe4951444c20897a84bfad08ef\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/cfe3ffc378b1abbe4951444c20897a84bfad08ef\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cfe3ffc378b1abbe4951444c20897a84bfad08ef/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340\"}]},{\"sha\":\"b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T14:46:06Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-27T14:46:06Z\"},\"message\":\"Add Review and Testimonial Functionality\",\"tree\":{\"sha\":\"508ce9991ae1ccace2dc54d531afcfb586ad1cba\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/508ce9991ae1ccace2dc54d531afcfb586ad1cba\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/b871eb4a5f66c36f6a1c5e3d7a5118ec516dd340/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"1b925fd112832f1b6eb64f8af81a4188ac07cad8\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1b925fd112832f1b6eb64f8af81a4188ac07cad8\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1b925fd112832f1b6eb64f8af81a4188ac07cad8\"}]},{\"sha\":\"1b925fd112832f1b6eb64f8af81a4188ac07cad8\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-16T16:47:51Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-16T16:47:51Z\"},\"message\":\"Update Default Bootstrap3 Theme\",\"tree\":{\"sha\":\"820bd5de1338164e5b9867a52739816e66cf4c32\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/820bd5de1338164e5b9867a52739816e66cf4c32\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/1b925fd112832f1b6eb64f8af81a4188ac07cad8\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1b925fd112832f1b6eb64f8af81a4188ac07cad8\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1b925fd112832f1b6eb64f8af81a4188ac07cad8\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1b925fd112832f1b6eb64f8af81a4188ac07cad8/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"4407e940814253a691ad8da628d80b2935146ac5\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/4407e940814253a691ad8da628d80b2935146ac5\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/4407e940814253a691ad8da628d80b2935146ac5\"}]},{\"sha\":\"4407e940814253a691ad8da628d80b2935146ac5\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-16T13:47:19Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-16T13:47:19Z\"},\"message\":\"Update elFinder. Fix SEO References.\",\"tree\":{\"sha\":\"3a58ebd3bee2cc9b378529b57e98065cb5b087ef\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/3a58ebd3bee2cc9b378529b57e98065cb5b087ef\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/4407e940814253a691ad8da628d80b2935146ac5\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/4407e940814253a691ad8da628d80b2935146ac5\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/4407e940814253a691ad8da628d80b2935146ac5\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/4407e940814253a691ad8da628d80b2935146ac5/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"6aed222c09902b56e5c64a9e9327fa8a0030637b\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/6aed222c09902b56e5c64a9e9327fa8a0030637b\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/6aed222c09902b56e5c64a9e9327fa8a0030637b\"}]},{\"sha\":\"6aed222c09902b56e5c64a9e9327fa8a0030637b\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-14T15:29:22Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-14T15:29:22Z\"},\"message\":\"Update elFinder. Fix SEO References.\",\"tree\":{\"sha\":\"22c9d8830ed0d2f32b69c45cbc5ca6d10452029e\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/22c9d8830ed0d2f32b69c45cbc5ca6d10452029e\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/6aed222c09902b56e5c64a9e9327fa8a0030637b\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/6aed222c09902b56e5c64a9e9327fa8a0030637b\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/6aed222c09902b56e5c64a9e9327fa8a0030637b\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/6aed222c09902b56e5c64a9e9327fa8a0030637b/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"73098103b8d928564314381f9648484a842d50b7\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/73098103b8d928564314381f9648484a842d50b7\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/73098103b8d928564314381f9648484a842d50b7\"}]},{\"sha\":\"73098103b8d928564314381f9648484a842d50b7\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-13T16:35:08Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-13T16:35:08Z\"},\"message\":\"Add SEO Tools to Summernote, Fix and Add Fields to Database.\",\"tree\":{\"sha\":\"b9d43db43f795fd5b684546a9d1978234fbced8b\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/b9d43db43f795fd5b684546a9d1978234fbced8b\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/73098103b8d928564314381f9648484a842d50b7\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/73098103b8d928564314381f9648484a842d50b7\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/73098103b8d928564314381f9648484a842d50b7\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/73098103b8d928564314381f9648484a842d50b7/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"1be0277d465204e9888405932489af74d6cc4aaa\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1be0277d465204e9888405932489af74d6cc4aaa\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1be0277d465204e9888405932489af74d6cc4aaa\"}]},{\"sha\":\"1be0277d465204e9888405932489af74d6cc4aaa\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-09T15:01:43Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-09T15:01:43Z\"},\"message\":\"Fix Front End Orders and Update TCPDF\",\"tree\":{\"sha\":\"cb7017eec14795a41f9ea218693487ec2d3703ab\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/cb7017eec14795a41f9ea218693487ec2d3703ab\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/1be0277d465204e9888405932489af74d6cc4aaa\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1be0277d465204e9888405932489af74d6cc4aaa\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1be0277d465204e9888405932489af74d6cc4aaa\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1be0277d465204e9888405932489af74d6cc4aaa/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b\"}]},{\"sha\":\"42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-07T17:30:41Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-07T17:30:41Z\"},\"message\":\"Fix SEO URL to use Entities\",\"tree\":{\"sha\":\"4527488b29654a4bbd7f19d475b9473a945cc6e1\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/4527488b29654a4bbd7f19d475b9473a945cc6e1\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/42cf4a947cf1f418a958ae34fc9a8e3e09db1f4b/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"b3eb5423139d5ca522a24d28480e031f1dd92e5f\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/b3eb5423139d5ca522a24d28480e031f1dd92e5f\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/b3eb5423139d5ca522a24d28480e031f1dd92e5f\"}]},{\"sha\":\"b3eb5423139d5ca522a24d28480e031f1dd92e5f\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-04T06:29:57Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-04T06:29:57Z\"},\"message\":\"Add Live URL Theme Viewing\",\"tree\":{\"sha\":\"f1944ea8b66543a74211e5a5422d0cd24e5ccb37\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/f1944ea8b66543a74211e5a5422d0cd24e5ccb37\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/b3eb5423139d5ca522a24d28480e031f1dd92e5f\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/b3eb5423139d5ca522a24d28480e031f1dd92e5f\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/b3eb5423139d5ca522a24d28480e031f1dd92e5f\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/b3eb5423139d5ca522a24d28480e031f1dd92e5f/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"3d378237cb531c83c62be66ddb825c1806177851\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/3d378237cb531c83c62be66ddb825c1806177851\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/3d378237cb531c83c62be66ddb825c1806177851\"}]},{\"sha\":\"3d378237cb531c83c62be66ddb825c1806177851\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T17:21:27Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T17:21:27Z\"},\"message\":\"Update Default Bootstrap 3 Theme\",\"tree\":{\"sha\":\"3ca29a1060825f7c9cbb1097a5e51758922355bf\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/3ca29a1060825f7c9cbb1097a5e51758922355bf\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/3d378237cb531c83c62be66ddb825c1806177851\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/3d378237cb531c83c62be66ddb825c1806177851\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/3d378237cb531c83c62be66ddb825c1806177851\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/3d378237cb531c83c62be66ddb825c1806177851/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"2832e78a61fb858ed056c751ade56f2f6c6e96a8\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/2832e78a61fb858ed056c751ade56f2f6c6e96a8\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/2832e78a61fb858ed056c751ade56f2f6c6e96a8\"}]},{\"sha\":\"2832e78a61fb858ed056c751ade56f2f6c6e96a8\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T13:52:44Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T13:52:44Z\"},\"message\":\"Update Readme, Add FAQ\",\"tree\":{\"sha\":\"6d517e2efdd6b4c9199edd6f1a2911ecd7274f3d\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/6d517e2efdd6b4c9199edd6f1a2911ecd7274f3d\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/2832e78a61fb858ed056c751ade56f2f6c6e96a8\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/2832e78a61fb858ed056c751ade56f2f6c6e96a8\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/2832e78a61fb858ed056c751ade56f2f6c6e96a8\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/2832e78a61fb858ed056c751ade56f2f6c6e96a8/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"408615c9519089c2272abcc0066f8f2566378386\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/408615c9519089c2272abcc0066f8f2566378386\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/408615c9519089c2272abcc0066f8f2566378386\"}]},{\"sha\":\"408615c9519089c2272abcc0066f8f2566378386\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T13:48:45Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T13:48:45Z\"},\"message\":\"Update Readme, Add FAQ\",\"tree\":{\"sha\":\"59a4cc6a9acea7d9db01828405ed468a9296abb7\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/59a4cc6a9acea7d9db01828405ed468a9296abb7\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/408615c9519089c2272abcc0066f8f2566378386\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/408615c9519089c2272abcc0066f8f2566378386\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/408615c9519089c2272abcc0066f8f2566378386\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/408615c9519089c2272abcc0066f8f2566378386/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"8c232a97dcb250582cb39b4cda061791b96b47eb\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/8c232a97dcb250582cb39b4cda061791b96b47eb\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/8c232a97dcb250582cb39b4cda061791b96b47eb\"}]},{\"sha\":\"8c232a97dcb250582cb39b4cda061791b96b47eb\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T13:30:43Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-06-02T13:30:43Z\"},\"message\":\"Update & Fix Multiple Issues\",\"tree\":{\"sha\":\"149989d4a1e102002e44f743fefb69077d25188b\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/149989d4a1e102002e44f743fefb69077d25188b\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/8c232a97dcb250582cb39b4cda061791b96b47eb\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/8c232a97dcb250582cb39b4cda061791b96b47eb\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/8c232a97dcb250582cb39b4cda061791b96b47eb\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/8c232a97dcb250582cb39b4cda061791b96b47eb/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"0adddc1b4265bc78018bb6c68cc24ea24b32f3d6\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/0adddc1b4265bc78018bb6c68cc24ea24b32f3d6\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/0adddc1b4265bc78018bb6c68cc24ea24b32f3d6\"}]},{\"sha\":\"0adddc1b4265bc78018bb6c68cc24ea24b32f3d6\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-28T08:29:30Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-28T08:29:30Z\"},\"message\":\"Fix Backup/Restor Functions.\",\"tree\":{\"sha\":\"3388564d449af7229336a7c5873a837c9ce02859\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/3388564d449af7229336a7c5873a837c9ce02859\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/0adddc1b4265bc78018bb6c68cc24ea24b32f3d6\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/0adddc1b4265bc78018bb6c68cc24ea24b32f3d6\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/0adddc1b4265bc78018bb6c68cc24ea24b32f3d6\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/0adddc1b4265bc78018bb6c68cc24ea24b32f3d6/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"1ace439dfeaf129254d5a405b73df4190b5b5154\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1ace439dfeaf129254d5a405b73df4190b5b5154\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1ace439dfeaf129254d5a405b73df4190b5b5154\"}]},{\"sha\":\"1ace439dfeaf129254d5a405b73df4190b5b5154\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-27T10:46:47Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-27T10:46:47Z\"},\"message\":\"Add html file inclusion for carousel, and add caching to Dashboard RSS Feeds\",\"tree\":{\"sha\":\"a21da8338cd44eee9facac540e268608c3f905db\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/a21da8338cd44eee9facac540e268608c3f905db\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/1ace439dfeaf129254d5a405b73df4190b5b5154\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1ace439dfeaf129254d5a405b73df4190b5b5154\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1ace439dfeaf129254d5a405b73df4190b5b5154\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1ace439dfeaf129254d5a405b73df4190b5b5154/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef\"}]},{\"sha\":\"d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-24T17:13:33Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-24T17:13:33Z\"},\"message\":\"Fix Meta/Link HEAD Tags and GA Tracking Options\",\"tree\":{\"sha\":\"48c8995a079d1e9d54de7d44455c06591f21150a\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/48c8995a079d1e9d54de7d44455c06591f21150a\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/d0f567b5a0a730c6470eaf9d53a65af1e3afe1ef/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"cd3fe9e7a559f353d5af0013a808c0b8bf41b156\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cd3fe9e7a559f353d5af0013a808c0b8bf41b156\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/cd3fe9e7a559f353d5af0013a808c0b8bf41b156\"}]},{\"sha\":\"cd3fe9e7a559f353d5af0013a808c0b8bf41b156\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-24T03:59:23Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-24T03:59:23Z\"},\"message\":\"Add RSS Feeds option to Dashboard, and Enable Feeds/Git Commits options\",\"tree\":{\"sha\":\"49d37f4cc8703f0f2c5e00e034fb5a5f8097d7bb\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/49d37f4cc8703f0f2c5e00e034fb5a5f8097d7bb\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/cd3fe9e7a559f353d5af0013a808c0b8bf41b156\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cd3fe9e7a559f353d5af0013a808c0b8bf41b156\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/cd3fe9e7a559f353d5af0013a808c0b8bf41b156\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/cd3fe9e7a559f353d5af0013a808c0b8bf41b156/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"1d4913f87ad3308536330dd672ca228a48c0088c\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1d4913f87ad3308536330dd672ca228a48c0088c\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1d4913f87ad3308536330dd672ca228a48c0088c\"}]},{\"sha\":\"1d4913f87ad3308536330dd672ca228a48c0088c\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-24T03:58:57Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-24T03:58:57Z\"},\"message\":\"Add Google Analytics to Dashboard\",\"tree\":{\"sha\":\"9c7827fd72d9acde939dcba54cf551272f43f6b3\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/9c7827fd72d9acde939dcba54cf551272f43f6b3\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/1d4913f87ad3308536330dd672ca228a48c0088c\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1d4913f87ad3308536330dd672ca228a48c0088c\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/1d4913f87ad3308536330dd672ca228a48c0088c\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/1d4913f87ad3308536330dd672ca228a48c0088c/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"14e815092c1b41af9f6776f5e2fb7e9afad9d404\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/14e815092c1b41af9f6776f5e2fb7e9afad9d404\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/14e815092c1b41af9f6776f5e2fb7e9afad9d404\"}]},{\"sha\":\"14e815092c1b41af9f6776f5e2fb7e9afad9d404\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-22T13:00:24Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-22T13:00:24Z\"},\"message\":\"Add RSS Feeds option to Dashboard, and Enable Feeds/Git Commits options\",\"tree\":{\"sha\":\"2fed6c9f6f323b37e04af394d44d24cdbe717e87\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/2fed6c9f6f323b37e04af394d44d24cdbe717e87\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/14e815092c1b41af9f6776f5e2fb7e9afad9d404\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/14e815092c1b41af9f6776f5e2fb7e9afad9d404\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/14e815092c1b41af9f6776f5e2fb7e9afad9d404\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/14e815092c1b41af9f6776f5e2fb7e9afad9d404/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"ccdaaf5b836b8872c27fe36fdee2850d519180a6\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/ccdaaf5b836b8872c27fe36fdee2850d519180a6\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/ccdaaf5b836b8872c27fe36fdee2850d519180a6\"}]},{\"sha\":\"ccdaaf5b836b8872c27fe36fdee2850d519180a6\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-22T06:18:33Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-22T06:18:33Z\"},\"message\":\"Update Features of summernote-image-attributes Plugin\",\"tree\":{\"sha\":\"6a846bd45c4172ff6e79f3714c5903a5c7322dad\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/6a846bd45c4172ff6e79f3714c5903a5c7322dad\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/ccdaaf5b836b8872c27fe36fdee2850d519180a6\",\"comment_count\":1},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/ccdaaf5b836b8872c27fe36fdee2850d519180a6\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/ccdaaf5b836b8872c27fe36fdee2850d519180a6\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/ccdaaf5b836b8872c27fe36fdee2850d519180a6/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57\"}]},{\"sha\":\"90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57\",\"commit\":{\"author\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-20T04:06:08Z\"},\"committer\":{\"name\":\"StudioJunkyard\",\"email\":\"info@studiojunkyard.com\",\"date\":\"2016-05-20T04:06:08Z\"},\"message\":\"Make Git_Commit reader more Ajax Like to reduce page blocking\",\"tree\":{\"sha\":\"6371c693f661df1ed4609e9df7c09b5545e6e86b\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/trees/6371c693f661df1ed4609e9df7c09b5545e6e86b\"},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/git/commits/90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57\",\"comment_count\":0},\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57\",\"comments_url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/90642e8d7f7fe4ca9ad99d15c8d4ed9ca7952a57/comments\",\"author\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"committer\":{\"login\":\"StudioJunkyard\",\"id\":841740,\"avatar_url\":\"https://avatars.githubusercontent.com/u/841740?v=3\",\"gravatar_id\":\"\",\"url\":\"https://api.github.com/users/StudioJunkyard\",\"html_url\":\"https://github.com/StudioJunkyard\",\"followers_url\":\"https://api.github.com/users/StudioJunkyard/followers\",\"following_url\":\"https://api.github.com/users/StudioJunkyard/following{/other_user}\",\"gists_url\":\"https://api.github.com/users/StudioJunkyard/gists{/gist_id}\",\"starred_url\":\"https://api.github.com/users/StudioJunkyard/starred{/owner}{/repo}\",\"subscriptions_url\":\"https://api.github.com/users/StudioJunkyard/subscriptions\",\"organizations_url\":\"https://api.github.com/users/StudioJunkyard/orgs\",\"repos_url\":\"https://api.github.com/users/StudioJunkyard/repos\",\"events_url\":\"https://api.github.com/users/StudioJunkyard/events{/privacy}\",\"received_events_url\":\"https://api.github.com/users/StudioJunkyard/received_events\",\"type\":\"User\",\"site_admin\":false},\"parents\":[{\"sha\":\"a9949642dd1c7e9a4b8621688d1d03822e69e0e0\",\"url\":\"https://api.github.com/repos/StudioJunkyard/LibreCMS/commits/a9949642dd1c7e9a4b8621688d1d03822e69e0e0\",\"html_url\":\"https://github.com/StudioJunkyard/LibreCMS/commit/a9949642dd1c7e9a4b8621688d1d03822e69e0e0\"}]}]`,1469018435,``,``,``,``,``,``,``,``,``,``,`1011111000000000`,`mjdwnwereioy`,``,``,`11000000`,0,1280,1280,250,250,95,0,0,1549265296,0,3600,`https://www.studiojunkyard.com/update/`,0,0,0);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `content`;

CREATE TABLE IF NOT EXISTS `content` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mid` bigint(20) DEFAULT NULL,
  `options` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '00000000',
  `rank` int(4) DEFAULT NULL,
  `rid` bigint(20) unsigned DEFAULT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `login_user` varchar(128) COLLATE utf8_bin NOT NULL,
  `cid` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `contentType` varchar(16) COLLATE utf8_bin NOT NULL,
  `schemaType` varchar(40) COLLATE utf8_bin NOT NULL,
  `seoKeywords` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `barcode` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `fccid` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `code` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  `brand` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `title` varchar(60) COLLATE utf8_bin DEFAULT NULL,
  `category_1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `category_2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `url` varchar(256) COLLATE utf8_bin NOT NULL,
  `email` varchar(60) COLLATE utf8_bin NOT NULL,
  `business` varchar(40) COLLATE utf8_bin NOT NULL,
  `address` varchar(80) COLLATE utf8_bin NOT NULL,
  `suburb` varchar(40) COLLATE utf8_bin NOT NULL,
  `city` varchar(40) COLLATE utf8_bin NOT NULL,
  `state` varchar(40) COLLATE utf8_bin NOT NULL,
  `postcode` mediumint(5) unsigned NOT NULL,
  `phone` varchar(14) COLLATE utf8_bin NOT NULL,
  `mobile` varchar(14) COLLATE utf8_bin NOT NULL,
  `thumb` varchar(128) COLLATE utf8_bin NOT NULL,
  `file` varchar(128) COLLATE utf8_bin NOT NULL,
  `fileURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `attributionImageTitle` tinytext COLLATE utf8_bin NOT NULL,
  `attributionImageName` tinytext COLLATE utf8_bin NOT NULL,
  `attributionImageURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `exifISO` varchar(4) COLLATE utf8_bin NOT NULL,
  `exifAperture` varchar(2) COLLATE utf8_bin NOT NULL,
  `exifFocalLength` varchar(8) COLLATE utf8_bin NOT NULL,
  `exifShutterSpeed` varchar(10) COLLATE utf8_bin NOT NULL,
  `exifCamera` tinytext COLLATE utf8_bin NOT NULL,
  `exifLens` tinytext COLLATE utf8_bin NOT NULL,
  `exifFilename` tinytext COLLATE utf8_bin NOT NULL,
  `exifti` int(10) NOT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `subject` varchar(60) COLLATE utf8_bin NOT NULL,
  `notes` text COLLATE utf8_bin NOT NULL,
  `attributionContentName` tinytext COLLATE utf8_bin NOT NULL,
  `attributionContentURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `quantity` mediumint(20) unsigned NOT NULL,
  `tags` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoTitle` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoCaption` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoDescription` varchar(255) COLLATE utf8_bin NOT NULL,
  `metaRobots` tinytext COLLATE utf8_bin NOT NULL,
  `status` varchar(16) COLLATE utf8_bin NOT NULL,
  `service` bigint(20) unsigned NOT NULL,
  `internal` tinyint(1) unsigned NOT NULL,
  `featured` tinyint(1) unsigned NOT NULL,
  `bookable` tinyint(1) NOT NULL,
  `fti` int(10) unsigned NOT NULL,
  `assoc` varchar(128) COLLATE utf8_bin NOT NULL,
  `ord` bigint(20) unsigned NOT NULL,
  `views` bigint(20) unsigned NOT NULL,
  `suggestions` int(1) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL,
  `pin` tinyint(1) NOT NULL,
  `tis` int(10) unsigned NOT NULL,
  `tie` int(10) unsigned NOT NULL,
  `lti` int(10) unsigned NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  `eti` int(10) NOT NULL,
  `pti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `content` (id, mid, options, rank, rid, uid, login_user, cid, ip, contentType, schemaType, seoKeywords, barcode, fccid, code, brand, title, category_1, category_2, name, url, email, business, address, suburb, city, state, postcode, phone, mobile, thumb, file, fileURL, attributionImageTitle, attributionImageName, attributionImageURL, exifISO, exifAperture, exifFocalLength, exifShutterSpeed, exifCamera, exifLens, exifFilename, exifti, cost, subject, notes, attributionContentName, attributionContentURL, quantity, tags, seoTitle, seoCaption, seoDescription, metaRobots, status, service, internal, featured, bookable, fti, assoc, ord, views, suggestions, active, pin, tis, tie, lti, ti, eti, pti) VALUES
	(7,,`10000000`,,,1,`Kenika Suitters`,0,``,`article`,`Service`,``,``,``,``,``,`Articlel 1`,``,``,`Dennis Suitters`,``,`dennis@studiojunkyard.com`,`Studio Junkyard`,``,``,``,``,0,``,``,``,``,`https://picsum.photos/750/500?image=976`,``,``,``,``,``,``,``,``,``,``,0,20.00,``,`<p>And this isn\'t my nose. This is a false one. Camelot! Well, we did do the nose. Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Why do you think that she is a witch? I have to push the pram a lot.</p>
<p>I dunno. Must be a king. You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you! The Knights Who Say Ni demand a sacrifice! She looks like one. How do you know she is a witch?</p>
`,``,``,100,``,``,``,``,``,`published`,0,0,1,0,0,``,0,11,0,1,0,0,0,0,1541063590,1548505210,1548495069),
	(8,,`00000000`,,,1,`Kenika Suitters`,,``,`article`,`blogPosting`,``,``,``,``,``,`Article 8`,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,`https://picsum.photos/750/500?image=900`,``,``,``,``,``,``,``,``,``,``,0,,``,`<p>And this isn\'t my nose. This is a false one. Camelot! Well, we did do the nose. Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Why do you think that she is a witch? I have to push the pram a lot.</p>
<p>I dunno. Must be a king. You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you! The Knights Who Say Ni demand a sacrifice! She looks like one. How do you know she is a witch?</p>
<h2>Well, how\'d you become king, then?</h2>
<p>Shut up! Ah, now we see the violence inherent in the system! I have to push the pram a lot. And the hat. She\'s a witch! I dunno. Must be a king.</p>
<p>Where\'d you get the coconuts? It\'s only a model. Why do you think that she is a witch? We want a shrubbery!! Ni! Ni! Ni! Ni! She looks like one.</p>
<h3>How do you know she is a witch?</h3>
<p>I\'m not a witch. We found them. Bloody Peasant! Well, she turned me into a newt. How do you know she is a witch?</p>
<p>I am your king. Camelot! Where\'d you get the coconuts? And the hat. She\'s a witch! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>And the hat. She\'s a witch! We shall say \'Ni\' again to you, if you do not appease us. You don\'t vote for kings. But you are dressed as one… The swallow may fly south with the sun, and the house martin or the plover may seek warmer climes in winter, yet these are not strangers to our land.</p>
<p>The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king. Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>Where\'d you get the coconuts? We found them. The nose? Well, Mercia\'s a temperate zone! Where\'d you get the coconuts? Burn her anyway!</p>
<p>And the hat. She\'s a witch! Shut up! Shut up! We want a shrubbery!! Oh, ow!</p>
<p>Well, Mercia\'s a temperate zone! Oh, ow! We found them. You don\'t vote for kings.</p>
<p>What a strange person. A newt? A newt? The nose? Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>And this isn\'t my nose. This is a false one. Shut up! Will you shut up?! The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king.</p>
<p>How do you know she is a witch? Shut up! Will you shut up?! Burn her anyway! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods. On second thoughts, let\'s not go there. It is a silly place.</p>
<p>Burn her! I\'m not a witch. We found them. Be quiet! Bring her forward!</p>
<p>Oh! Come and see the violence inherent in the system! Help, help, I\'m being repressed! Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>Bring her forward! Ni! Ni! Ni! Ni! What a strange person. I have to push the pram a lot. Why?</p>`,``,``,0,``,``,``,``,``,`published`,0,0,0,0,0,``,0,1,0,1,0,0,0,0,1541076960,1548505287,1548207912),
	(9,,`00000000`,,,1,`Kenika Suitters`,,``,`portfolio`,`blogPosting`,``,``,``,``,``,`Project 9`,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,`https://picsum.photos/750/500?image=881`,``,``,``,``,``,``,``,``,``,``,0,,``,`<p>And this isn\'t my nose. This is a false one. Camelot! Well, we did do the nose. Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Why do you think that she is a witch? I have to push the pram a lot.</p>
<p>I dunno. Must be a king. You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you! The Knights Who Say Ni demand a sacrifice! She looks like one. How do you know she is a witch?</p>
<h2>Well, how\'d you become king, then?</h2>
<p>Shut up! Ah, now we see the violence inherent in the system! I have to push the pram a lot. And the hat. She\'s a witch! I dunno. Must be a king.</p>
<p>Where\'d you get the coconuts? It\'s only a model. Why do you think that she is a witch? We want a shrubbery!! Ni! Ni! Ni! Ni! She looks like one.</p>
<h3>How do you know she is a witch?</h3>
<p>I\'m not a witch. We found them. Bloody Peasant! Well, she turned me into a newt. How do you know she is a witch?</p>
<p>I am your king. Camelot! Where\'d you get the coconuts? And the hat. She\'s a witch! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>And the hat. She\'s a witch! We shall say \'Ni\' again to you, if you do not appease us. You don\'t vote for kings. But you are dressed as one… The swallow may fly south with the sun, and the house martin or the plover may seek warmer climes in winter, yet these are not strangers to our land.</p>
<p>The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king. Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>Where\'d you get the coconuts? We found them. The nose? Well, Mercia\'s a temperate zone! Where\'d you get the coconuts? Burn her anyway!</p>
<p>And the hat. She\'s a witch! Shut up! Shut up! We want a shrubbery!! Oh, ow!</p>
<p>Well, Mercia\'s a temperate zone! Oh, ow! We found them. You don\'t vote for kings.</p>
<p>What a strange person. A newt? A newt? The nose? Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>And this isn\'t my nose. This is a false one. Shut up! Will you shut up?! The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king.</p>
<p>How do you know she is a witch? Shut up! Will you shut up?! Burn her anyway! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods. On second thoughts, let\'s not go there. It is a silly place.</p>
<p>Burn her! I\'m not a witch. We found them. Be quiet! Bring her forward!</p>
<p>Oh! Come and see the violence inherent in the system! Help, help, I\'m being repressed! Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>Bring her forward! Ni! Ni! Ni! Ni! What a strange person. I have to push the pram a lot. Why?</p>`,``,``,0,``,``,``,``,``,`published`,0,0,0,0,0,``,0,88,0,1,0,0,0,0,1541076989,1548207955,1541077008),
	(10,,`01000000`,,,1,`Kenika Suitters`,,``,`portfolio`,`blogPosting`,``,``,``,``,``,`Project 10`,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,`https://picsum.photos/750/500?image=903`,``,``,``,``,``,``,``,``,``,``,0,,``,`<p>And this isn\'t my nose. This is a false one. Camelot! Well, we did do the nose. Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Why do you think that she is a witch? I have to push the pram a lot.</p>
<p>I dunno. Must be a king. You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you! The Knights Who Say Ni demand a sacrifice! She looks like one. How do you know she is a witch?</p>
<h2>Well, how\'d you become king, then?</h2>
<p>Shut up! Ah, now we see the violence inherent in the system! I have to push the pram a lot. And the hat. She\'s a witch! I dunno. Must be a king.</p>
<p>Where\'d you get the coconuts? It\'s only a model. Why do you think that she is a witch? We want a shrubbery!! Ni! Ni! Ni! Ni! She looks like one.</p>
<h3>How do you know she is a witch?</h3>
<p>I\'m not a witch. We found them. Bloody Peasant! Well, she turned me into a newt. How do you know she is a witch?</p>
<p>I am your king. Camelot! Where\'d you get the coconuts? And the hat. She\'s a witch! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>And the hat. She\'s a witch! We shall say \'Ni\' again to you, if you do not appease us. You don\'t vote for kings. But you are dressed as one… The swallow may fly south with the sun, and the house martin or the plover may seek warmer climes in winter, yet these are not strangers to our land.</p>
<p>The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king. Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>Where\'d you get the coconuts? We found them. The nose? Well, Mercia\'s a temperate zone! Where\'d you get the coconuts? Burn her anyway!</p>
<p>And the hat. She\'s a witch! Shut up! Shut up! We want a shrubbery!! Oh, ow!</p>
<p>Well, Mercia\'s a temperate zone! Oh, ow! We found them. You don\'t vote for kings.</p>
<p>What a strange person. A newt? A newt? The nose? Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>And this isn\'t my nose. This is a false one. Shut up! Will you shut up?! The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king.</p>
<p>How do you know she is a witch? Shut up! Will you shut up?! Burn her anyway! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods. On second thoughts, let\'s not go there. It is a silly place.</p>
<p>Burn her! I\'m not a witch. We found them. Be quiet! Bring her forward!</p>
<p>Oh! Come and see the violence inherent in the system! Help, help, I\'m being repressed! Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>Bring her forward! Ni! Ni! Ni! Ni! What a strange person. I have to push the pram a lot. Why?</p>`,``,``,0,``,``,``,``,``,`published`,0,0,0,0,0,``,0,24,0,1,0,0,0,0,1541077013,1548208067,1545659946),
	(11,,`00000000`,,,1,`Kenika Suitters`,,``,`article`,`blogPosting`,``,``,``,``,``,`Article 11`,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,`https://picsum.photos/750/500?image=944`,``,``,``,``,``,``,``,``,``,``,0,,``,`<p>And this isn\'t my nose. This is a false one. Camelot! Well, we did do the nose. Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Why do you think that she is a witch? I have to push the pram a lot.</p>
<p>I dunno. Must be a king. You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you! The Knights Who Say Ni demand a sacrifice! She looks like one. How do you know she is a witch?</p>
<h2>Well, how\'d you become king, then?</h2>
<p>Shut up! Ah, now we see the violence inherent in the system! I have to push the pram a lot. And the hat. She\'s a witch! I dunno. Must be a king.</p>
<p>Where\'d you get the coconuts? It\'s only a model. Why do you think that she is a witch? We want a shrubbery!! Ni! Ni! Ni! Ni! She looks like one.</p>
<h3>How do you know she is a witch?</h3>
<p>I\'m not a witch. We found them. Bloody Peasant! Well, she turned me into a newt. How do you know she is a witch?</p>
<p>I am your king. Camelot! Where\'d you get the coconuts? And the hat. She\'s a witch! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>And the hat. She\'s a witch! We shall say \'Ni\' again to you, if you do not appease us. You don\'t vote for kings. But you are dressed as one… The swallow may fly south with the sun, and the house martin or the plover may seek warmer climes in winter, yet these are not strangers to our land.</p>
<p>The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king. Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>Where\'d you get the coconuts? We found them. The nose? Well, Mercia\'s a temperate zone! Where\'d you get the coconuts? Burn her anyway!</p>
<p>And the hat. She\'s a witch! Shut up! Shut up! We want a shrubbery!! Oh, ow!</p>
<p>Well, Mercia\'s a temperate zone! Oh, ow! We found them. You don\'t vote for kings.</p>
<p>What a strange person. A newt? A newt? The nose? Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>And this isn\'t my nose. This is a false one. Shut up! Will you shut up?! The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king.</p>
<p>How do you know she is a witch? Shut up! Will you shut up?! Burn her anyway! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods. On second thoughts, let\'s not go there. It is a silly place.</p>
<p>Burn her! I\'m not a witch. We found them. Be quiet! Bring her forward!</p>
<p>Oh! Come and see the violence inherent in the system! Help, help, I\'m being repressed! Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>Bring her forward! Ni! Ni! Ni! Ni! What a strange person. I have to push the pram a lot. Why?</p>`,``,``,0,``,``,``,``,``,`published`,0,0,0,0,0,``,0,33,0,1,0,0,0,0,1541077037,1548578909,1548578909),
	(12,,`10000000`,,,1,`Kenika Suitters`,,``,`service`,`Product`,``,``,``,`D101`,``,`Service 12`,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,`https://picsum.photos/750/500?image=977`,``,``,``,``,``,``,``,``,``,``,0,20.00,``,`<p>He hasn\'t got shit all over him. Ni! Ni! Ni! Ni! Well, we did do the nose. Why? Now, look here, my good man. Look, my liege!</p>
<p>I have to push the pram a lot. Burn her anyway! <strong> What do you mean?</strong> <em> Well, Mercia\'s a temperate zone!</em> Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<h2>A newt?</h2>
<p>Look, my liege! Bloody Peasant! He hasn\'t got shit all over him. What a strange person.</p>
<ol>
<li>We found them.</li><li>She looks like one.</li><li>I\'m not a witch.</li>
</ol>

<h3>You don\'t frighten us, English pig-dogs! Go and boil your bottoms, sons of a silly person! I blow my nose at you, so-called Ah-thoor Keeng, you and all your silly English K-n-n-n-n-n-n-n-niggits!</h3>
<p>Found them? In Mercia?! The coconut\'s tropical! No, no, no! Yes, yes. A bit. But she\'s got a wart. Bloody Peasant! Where\'d you get the coconuts? I\'m not a witch. …Are you suggesting that coconuts migrate?</p>
<ul>
<li>On second thoughts, let\'s not go there. It is a silly place.</li><li>Be quiet!</li><li>He hasn\'t got shit all over him.</li>
</ul>

<p>We found them. Well, I didn\'t vote for you. And this isn\'t my nose. This is a false one. Bloody Peasant! It\'s only a model.</p>
<p>Why? You don\'t frighten us, English pig-dogs! Go and boil your bottoms, sons of a silly person! I blow my nose at you, so-called Ah-thoor Keeng, you and all your silly English K-n-n-n-n-n-n-n-niggits! Where\'d you get the coconuts?</p>
<p>We want a shrubbery!! It\'s only a model. A newt? He hasn\'t got shit all over him. What do you mean?</p>
<p>Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods. What do you mean? Found them? In Mercia?! The coconut\'s tropical! Why do you think that she is a witch? Did you dress her up like this?</p>
<p>Shut up! Why do you think that she is a witch? Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>Did you dress her up like this? What a strange person. She looks like one. We found them. You don\'t vote for kings.</p>
<p>Why do you think that she is a witch? Bloody Peasant! Well, she turned me into a newt. But you are dressed as one… We found them.</p>
<p>Who\'s that then? On second thoughts, let\'s not go there. It is a silly place. The Knights Who Say Ni demand a sacrifice! …Are you suggesting that coconuts migrate? We shall say \'Ni\' again to you, if you do not appease us.</p>
<p>We found them. What a strange person. You don\'t frighten us, English pig-dogs! Go and boil your bottoms, sons of a silly person! I blow my nose at you, so-called Ah-thoor Keeng, you and all your silly English K-n-n-n-n-n-n-n-niggits!</p>
<p>…Are you suggesting that coconuts migrate? I am your king. But you are dressed as one… Found them? In Mercia?! The coconut\'s tropical! Well, Mercia\'s a temperate zone!</p>
<p>Oh, ow! What do you mean? Found them? In Mercia?! The coconut\'s tropical! He hasn\'t got shit all over him.</p>`,``,``,48,``,`Inventory 1 SEO Title`,``,``,``,`published`,0,0,0,1,0,``,0,0,0,1,0,0,0,0,1542445997,1548035730,1542446111),
	(13,,`10000000`,,,1,`Kenika Suitters`,,``,`service`,`Product`,``,``,``,`D102`,``,`Service 2`,`Category 1`,`Category 2`,``,``,``,``,``,``,``,``,0,``,``,``,``,`https://picsum.photos/750/500?image=1080`,``,``,``,``,``,``,``,``,``,``,0,30.00,``,`<p>He hasn\'t got shit all over him. Ni! Ni! Ni! Ni! Well, we did do the nose. Why? Now, look here, my good man. Look, my liege!</p>
<p>I have to push the pram a lot. Burn her anyway! <strong> What do you mean?</strong> <em> Well, Mercia\'s a temperate zone!</em> Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<h2>A newt?</h2>
<p>Look, my liege! Bloody Peasant! He hasn\'t got shit all over him. What a strange person.</p>
<ol>
<li>We found them.</li><li>She looks like one.</li><li>I\'m not a witch.</li>
</ol>

<h3>You don\'t frighten us, English pig-dogs! Go and boil your bottoms, sons of a silly person! I blow my nose at you, so-called Ah-thoor Keeng, you and all your silly English K-n-n-n-n-n-n-n-niggits!</h3>
<p>Found them? In Mercia?! The coconut\'s tropical! No, no, no! Yes, yes. A bit. But she\'s got a wart. Bloody Peasant! Where\'d you get the coconuts? I\'m not a witch. …Are you suggesting that coconuts migrate?</p>
<ul>
<li>On second thoughts, let\'s not go there. It is a silly place.</li><li>Be quiet!</li><li>He hasn\'t got shit all over him.</li>
</ul>

<p>We found them. Well, I didn\'t vote for you. And this isn\'t my nose. This is a false one. Bloody Peasant! It\'s only a model.</p>
<p>Why? You don\'t frighten us, English pig-dogs! Go and boil your bottoms, sons of a silly person! I blow my nose at you, so-called Ah-thoor Keeng, you and all your silly English K-n-n-n-n-n-n-n-niggits! Where\'d you get the coconuts?</p>
<p>We want a shrubbery!! It\'s only a model. A newt? He hasn\'t got shit all over him. What do you mean?</p>
<p>Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods. What do you mean? Found them? In Mercia?! The coconut\'s tropical! Why do you think that she is a witch? Did you dress her up like this?</p>
<p>Shut up! Why do you think that she is a witch? Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>Did you dress her up like this? What a strange person. She looks like one. We found them. You don\'t vote for kings.</p>
<p>Why do you think that she is a witch? Bloody Peasant! Well, she turned me into a newt. But you are dressed as one… We found them.</p>
<p>Who\'s that then? On second thoughts, let\'s not go there. It is a silly place. The Knights Who Say Ni demand a sacrifice! …Are you suggesting that coconuts migrate? We shall say \'Ni\' again to you, if you do not appease us.</p>
<p>We found them. What a strange person. You don\'t frighten us, English pig-dogs! Go and boil your bottoms, sons of a silly person! I blow my nose at you, so-called Ah-thoor Keeng, you and all your silly English K-n-n-n-n-n-n-n-niggits!</p>
<p>…Are you suggesting that coconuts migrate? I am your king. But you are dressed as one… Found them? In Mercia?! The coconut\'s tropical! Well, Mercia\'s a temperate zone!</p>
<p>Oh, ow! What do you mean? Found them? In Mercia?! The coconut\'s tropical! He hasn\'t got shit all over him.</p>`,``,``,43,`Tag 1,Tag 2,Tag 3`,``,``,``,``,`published`,0,0,0,0,0,``,0,51,0,1,0,0,0,0,1542446220,1548035670,1542446276),
	(34,,`00000000`,,,1,`Kenika Suitters`,,``,`newsletters`,``,``,``,``,``,``,`Test Newsletter`,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,``,``,``,``,``,``,``,``,``,``,``,0,,``,`<p>This is a test newletter</p>`,``,``,0,``,``,``,``,``,`published`,0,0,0,0,0,``,0,3,0,0,0,0,0,0,1547183479,1547184895,1547184895);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `iplist`;

CREATE TABLE IF NOT EXISTS `iplist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) COLLATE utf8_bin NOT NULL,
  `oti` int(10) NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `iplist` (id, ip, oti, ti) VALUES
	(1,`127.0.0.1`,1549264564,1549264564);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `login`;

CREATE TABLE IF NOT EXISTS `login` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `options` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '00000000',
  `bio_options` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '00000000000000000000000000000000',
  `adminTheme` varchar(32) COLLATE utf8_bin NOT NULL,
  `username` varchar(128) COLLATE utf8_bin NOT NULL,
  `password` varchar(256) COLLATE utf8_bin NOT NULL,
  `cover` varchar(60) COLLATE utf8_bin NOT NULL,
  `coverURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `attributionImageTitle` tinytext COLLATE utf8_bin NOT NULL,
  `attributionImageName` tinytext COLLATE utf8_bin NOT NULL,
  `attributionImageURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `avatar` varchar(60) COLLATE utf8_bin NOT NULL,
  `gravatar` varchar(256) COLLATE utf8_bin NOT NULL,
  `business` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(40) COLLATE utf8_bin NOT NULL,
  `email` varchar(60) COLLATE utf8_bin NOT NULL,
  `www` tinytext COLLATE utf8_bin NOT NULL,
  `experience` int(4) NOT NULL,
  `hash` varchar(32) COLLATE utf8_bin NOT NULL,
  `emailPassword` tinytext COLLATE utf8_bin NOT NULL,
  `email_check` int(10) NOT NULL,
  `url` varchar(256) COLLATE utf8_bin NOT NULL,
  `address` varchar(80) COLLATE utf8_bin NOT NULL,
  `suburb` varchar(40) COLLATE utf8_bin NOT NULL,
  `city` varchar(40) COLLATE utf8_bin NOT NULL,
  `state` varchar(40) COLLATE utf8_bin NOT NULL,
  `postcode` mediumint(5) unsigned NOT NULL,
  `country` tinytext COLLATE utf8_bin NOT NULL,
  `abn` varchar(32) COLLATE utf8_bin NOT NULL,
  `phone` varchar(14) COLLATE utf8_bin NOT NULL,
  `mobile` varchar(14) COLLATE utf8_bin NOT NULL,
  `caption` tinytext COLLATE utf8_bin NOT NULL,
  `notes` text COLLATE utf8_bin NOT NULL,
  `resume_notes` text COLLATE utf8_bin NOT NULL,
  `status` varchar(16) COLLATE utf8_bin NOT NULL,
  `active` tinyint(1) unsigned NOT NULL,
  `activate` varchar(255) COLLATE utf8_bin NOT NULL,
  `newsletter` int(1) NOT NULL DEFAULT '0',
  `language` varchar(8) COLLATE utf8_bin NOT NULL,
  `timezone` varchar(128) COLLATE utf8_bin NOT NULL,
  `rank` int(4) unsigned NOT NULL,
  `discount` varchar(4) COLLATE utf8_bin NOT NULL,
  `lti` int(10) NOT NULL,
  `userAgent` tinytext COLLATE utf8_bin NOT NULL,
  `userIP` varchar(32) COLLATE utf8_bin NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `login` (id, options, bio_options, adminTheme, username, password, cover, coverURL, attributionImageTitle, attributionImageName, attributionImageURL, avatar, gravatar, business, name, email, www, experience, hash, emailPassword, email_check, url, address, suburb, city, state, postcode, country, abn, phone, mobile, caption, notes, resume_notes, status, active, activate, newsletter, language, timezone, rank, discount, lti, userAgent, userIP, ti) VALUES
	(1,`11111111`,`11110000000000000000000000000000`,`dark`,`root`,`$2y$10$jtUwv6IykbGfUogDnoQHvet3lbL27GYHQ/b1/67FB4DVmroE6uEBS`,``,``,``,``,``,`avatar_1.jpg`,``,`Diemen Design`,`Kenika Suitters`,`dennis@diemen.design`,``,0,`fd8a15f03e7c9137fb57c3a8cf0d144f`,``,0,`https://diemen.design`,`128 Cradle Mtn Rd`,`Wilmot`,`Wilmot`,`Tasmania`,7310,`Australia`,``,`61364921418`,`61364921418`,`This is my Caption`,`I\'m not a witch. We found them. Bloody Peasant! Well, she turned me into a newt. How do you know she is a witch?
I am your king. Camelot! Where\'d you get the coconuts? And the hat. She\'s a witch! Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.
`,`This is my Career information.`,``,1,``,0,`en-AU`,`Australia/Hobart`,1000,``,1549248728,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,0);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `logs`;

CREATE TABLE IF NOT EXISTS `logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `rid` bigint(20) NOT NULL,
  `username` varchar(128) COLLATE utf8_bin NOT NULL,
  `name` varchar(40) COLLATE utf8_bin NOT NULL,
  `view` varchar(16) COLLATE utf8_bin NOT NULL,
  `contentType` varchar(16) COLLATE utf8_bin NOT NULL,
  `refTable` varchar(64) COLLATE utf8_bin NOT NULL,
  `refColumn` varchar(64) COLLATE utf8_bin NOT NULL,
  `oldda` longblob NOT NULL,
  `newda` longblob NOT NULL,
  `action` tinytext COLLATE utf8_bin NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `logs` (id, uid, rid, username, name, view, contentType, refTable, refColumn, oldda, newda, action, ti) VALUES
	(124,1,1,`root`,`Kenika Suitters`,``,``,`config`,`theme`,`bizzyknits`,`earthworx`,`update`,1548934303),
	(125,1,1,`root`,`Kenika Suitters`,``,``,`config`,`theme`,`earthworx`,`bizzyknits`,`update`,1548934307),
	(126,1,1,`root`,`Kenika Suitters`,``,``,`config`,`theme`,`bizzyknits`,`default`,`update`,1548935439),
	(127,1,1,`root`,`Kenika Suitters`,``,``,`config`,`theme`,`default`,`earthworx`,`update`,1548935441),
	(128,1,1,`root`,`Kenika Suitters`,``,``,`config`,`theme`,`earthworx`,`default`,`update`,1548935444),
	(129,1,1,`root`,`Kenika Suitters`,``,``,`config`,`theme`,`default`,`bizzyknits`,`update`,1548935446),
	(130,1,1,`root`,`Kenika Suitters`,``,``,`config`,`php_quicklink`,``,``,`update`,1548940364),
	(131,1,1,`root`,`Kenika Suitters`,``,``,`login`,`address`,`128 Cradle Mtn Rd`,`1264 Claude Rd`,`update`,1548986633),
	(132,1,1,`root`,`Kenika Suitters`,``,``,`login`,`address`,`1264 Claude Rd`,`128 Cradle Mtn Rd`,`update`,1548986641),
	(133,1,1,`root`,`Kenika Suitters`,``,``,`login`,`address`,`128 Cradle Mtn Rd`,`128 Cradle Mtn R`,`update`,1548987377),
	(134,1,1,`root`,`Kenika Suitters`,``,``,`login`,`address`,`128 Cradle Mtn R`,``,`update`,1548987382),
	(135,1,1,`root`,`Kenika Suitters`,``,``,`login`,`address`,``,`128 Cradle Mtn Rd`,`update`,1548991203),
	(136,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`1550195814`,`1550800614`,`update`,1549028703),
	(137,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`pending`,`overdue`,`update`,1549028719),
	(138,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`overdue`,`pending`,`update`,1549028722),
	(139,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`1550800614`,`1549504560`,`update`,1549028771),
	(140,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`1549504560`,`1550109360`,`update`,1549030581),
	(141,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`1550109360`,``,`update`,1549030884),
	(142,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`0`,``,`update`,1549030901),
	(143,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`0`,`1549462980`,`update`,1549030991),
	(144,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`1549462980`,`1550672580`,`update`,1549031037),
	(145,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`due_ti`,`1550672580`,`1549462980`,`update`,1549031049),
	(146,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`notes`,`%3Cp%3EServices%20are%20considered%20to%20be%20in%20a%20%3Cb%3EGrace%20Period%3C/b%3E%20for%20a%20total%20of%20%3Cb%3E14%20days%3C/b%3E%20whilst%20this%20invoice%20is%20outstanding.%20If%20no%20payment%20or%20contact%20to%20make%20payment%20arrangements%20has%20been%20forthcoming%20during%20the%20%3Cb%3E14%20Day%20Grace%20Period%3C/b%3E%2C%20any%20unpaid%20accounts%20will%20be%20%3Cb%3Esuspended%3C/b%3E%2C%20unless%20other%20arrangements%20have%20been%20made%20by%20contacting%20us%20%28Details%20at%20the%20top%20of%20the%20Invoice%29.%20If%20%3Cb%3E30%20days%3C/b%3E%20without%20payment%20or%20contact%20has%20lapsed%2C%20we%20will%20%3Cb%3Eat%20our%20discretion%3C/b%3E%20consider%20%3Cb%3Eterminating%3C/b%3E%20services%2C%20upon%20which%20you%20will%20be%20charged%20for%20the%20following%20full%20month%20as%20a%20termination%20fee.%20Following%20another%2030%20days%20%2860%20days%20or%202%20months%29%20from%20this%20Order%20Date%2C%20if%20no%20contact%20or%20resolution%20has%20been%20settled%2C%20we%20will%20remove/delete%20any%20data%20from%20our%20servers%20at%20our%20discretion.%3C/p%3E`,`Services are considered to be in a Grace Period for a total of 14 days whilst this invoice is outstanding. If no payment or contact to make payment arrangements has been forthcoming during the 14 Day Grace Period, any unpaid accounts will be suspended, unless other arrangements have been made by contacting us (Details at the top of the Invoice). If 30 days without payment or contact has lapsed, we will at our discretion consider terminating services, upon which you will be charged for the following full month as a termination fee. Following another 30 days (60 days or 2 months) from this Order Date, if no contact or resolution has been settled, we will remove/delete any data from our servers at our discretion.`,`update`,1549155245),
	(147,1,7,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`delete`,`update`,1549158002),
	(148,1,6,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`delete`,`update`,1549158005),
	(149,1,8,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`delete`,`update`,1549158133),
	(150,1,5,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`delete`,`update`,1549158135),
	(151,1,4,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`delete`,`update`,1549158137),
	(152,1,3,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`delete`,`update`,1549158140),
	(153,1,2,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`delete`,`update`,1549158142),
	(154,1,1,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`pending`,`delete`,`update`,1549158144),
	(155,1,9,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`outstanding`,`archived`,`update`,1549158155),
	(156,1,9,`root`,`Kenika Suitters`,``,``,`orders`,`status`,`archived`,`delete`,`update`,1549158167);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `media`;

CREATE TABLE IF NOT EXISTS `media` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) NOT NULL,
  `rid` bigint(20) NOT NULL,
  `file` varchar(128) COLLATE utf8_bin NOT NULL,
  `title` varchar(60) COLLATE utf8_bin NOT NULL,
  `category_1` varchar(30) COLLATE utf8_bin NOT NULL,
  `category_2` varchar(30) COLLATE utf8_bin NOT NULL,
  `attributionImageName` tinytext COLLATE utf8_bin NOT NULL,
  `attributionImageURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `exifISO` varchar(4) COLLATE utf8_bin NOT NULL,
  `exifAperture` varchar(2) COLLATE utf8_bin NOT NULL,
  `exifFocalLength` varchar(8) COLLATE utf8_bin NOT NULL,
  `exifShutterSpeed` varchar(10) COLLATE utf8_bin NOT NULL,
  `exifCamera` tinytext COLLATE utf8_bin NOT NULL,
  `exifLens` tinytext COLLATE utf8_bin NOT NULL,
  `exifFilename` tinytext COLLATE utf8_bin NOT NULL,
  `exifti` int(10) NOT NULL,
  `tags` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoTitle` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoCaption` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoDescription` varchar(255) COLLATE utf8_bin NOT NULL,
  `status` varchar(16) COLLATE utf8_bin NOT NULL,
  `views` bigint(20) NOT NULL,
  `suggestions` int(1) NOT NULL,
  `ord` bigint(20) NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `media` (id, pid, rid, file, title, category_1, category_2, attributionImageName, attributionImageURL, exifISO, exifAperture, exifFocalLength, exifShutterSpeed, exifCamera, exifLens, exifFilename, exifti, tags, seoTitle, seoCaption, seoDescription, status, views, suggestions, ord, ti) VALUES
	(13,10,0,`https://picsum.photos/700/500?image=870`,``,``,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,``,0,0,14,1543752995),
	(14,10,0,`https://picsum.photos/700/500?image=867`,``,``,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,``,0,0,15,1543753031),
	(15,10,0,`https://picsum.photos/700/500?image=829`,``,``,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,``,0,0,16,1543753074),
	(16,10,0,`https://picsum.photos/700/500?image=820`,``,``,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,``,0,0,17,1543753095),
	(17,10,0,`https://picsum.photos/700/500?image=808`,``,``,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,``,0,0,18,1543753120),
	(18,10,0,`https://picsum.photos/700/500?image=791`,``,``,``,``,``,``,``,``,``,``,``,``,0,``,``,``,``,``,0,0,19,1543753150);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `menu`;

CREATE TABLE IF NOT EXISTS `menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mid` bigint(20) NOT NULL DEFAULT '0',
  `uid` bigint(20) NOT NULL,
  `login_user` varchar(128) COLLATE utf8_bin NOT NULL,
  `title` varchar(60) COLLATE utf8_bin NOT NULL,
  `seoTitle` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `metaRobots` tinytext COLLATE utf8_bin NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `file` tinytext COLLATE utf8_bin NOT NULL,
  `cover` varchar(128) COLLATE utf8_bin NOT NULL,
  `coverURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `coverVideo` varchar(255) COLLATE utf8_bin NOT NULL,
  `attributionImageTitle` tinytext COLLATE utf8_bin NOT NULL,
  `attributionImageName` tinytext COLLATE utf8_bin NOT NULL,
  `attributionImageURL` varchar(256) COLLATE utf8_bin NOT NULL,
  `contentType` varchar(64) COLLATE utf8_bin NOT NULL,
  `schemaType` varchar(40) COLLATE utf8_bin NOT NULL,
  `seoKeywords` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoDescription` varchar(255) COLLATE utf8_bin NOT NULL,
  `seoCaption` varchar(255) COLLATE utf8_bin NOT NULL,
  `menu` varchar(16) COLLATE utf8_bin NOT NULL,
  `notes` text COLLATE utf8_bin NOT NULL,
  `ord` bigint(20) unsigned NOT NULL,
  `active` tinyint(1) unsigned NOT NULL,
  `views` bigint(20) NOT NULL,
  `suggestions` int(1) NOT NULL,
  `eti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `menu` (id, mid, uid, login_user, title, seoTitle, metaRobots, url, file, cover, coverURL, coverVideo, attributionImageTitle, attributionImageName, attributionImageURL, contentType, schemaType, seoKeywords, seoDescription, seoCaption, menu, notes, ord, active, views, suggestions, eti) VALUES
	(1,0,1,`Kenika Suitters`,`Home`,`Home SEO Title`,`index,follow`,``,`index`,`http://localhost/lCMS/media/homejumbo.jpg`,``,``,``,``,``,`index`,``,`home,seo,keywords`,`Home SEO Description`,`Home SEO Caption`,`head`,`<h2>Well, how\'d you become king, then?</h2>
<p>And this isn\'t my nose. This is a false one. Camelot! Well, we did do the nose. Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Why do you think that she is a witch? I have to push the pram a lot.</p>
<p>I dunno. Must be a king. You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you! The Knights Who Say Ni demand a sacrifice! She looks like one. How do you know she is a witch?</p>
`,0,1,122,0,1548770198),
	(2,0,1,`Kenika Suitters`,`Blog`,``,`index,follow`,``,`article`,``,``,``,``,``,``,`article`,``,``,``,``,`head`,``,4,1,52,0,1544766529),
	(3,0,1,`Kenika Suitters`,`Portfolio`,``,`index,follow`,``,`portfolio`,``,``,``,``,``,``,`portfolio`,``,``,``,``,`head`,``,3,1,50,0,1544766555),
	(4,0,1,`Kenika Suitters`,`Bookings`,``,`noindex`,``,`bookings`,``,``,``,``,``,``,`bookings`,``,``,``,``,`head`,``,5,1,23,0,1544766553),
	(5,0,1,`Kenika Suitters`,`Events`,``,`index,follow`,``,`events`,``,``,``,``,``,``,`events`,``,``,``,``,`head`,``,17,0,0,0,1544766557),
	(6,0,1,`Kenika Suitters`,`News`,``,`index,follow`,``,`news`,``,``,``,``,``,``,`news`,``,``,``,``,`head`,``,12,0,0,0,1544766548),
	(7,0,1,`Kenika Suitters`,`Testimonials`,``,`index,follow`,``,`testimonials`,``,``,``,``,``,``,`testimonials`,``,``,``,``,`head`,``,7,1,22,0,1544766533),
	(8,0,1,`Kenika Suitters`,`Products`,``,`index,follow`,``,`inventory`,``,``,``,``,``,``,`inventory`,``,``,``,``,`head`,``,13,0,0,0,1544766549),
	(9,0,1,`Kenika Suitters`,`Services`,``,`index,follow`,``,`services`,``,``,``,``,``,``,`service`,``,``,``,``,`head`,``,2,1,56,0,1544766547),
	(10,0,1,`Kenika Suitters`,`Gallery`,``,`index,follow`,``,`gallery`,``,``,``,``,``,``,`gallery`,``,``,``,``,`head`,``,9,0,0,0,1544766537),
	(11,0,1,`Kenika Suitters`,`Contact Us`,``,`noindex,nofollow`,``,`contactus`,``,``,``,``,``,``,`contactus`,``,``,``,``,`head`,``,6,1,23,0,1544766534),
	(12,0,1,`Kenika Suitters`,`Cart`,``,`noindex,nofollow`,``,`cart`,``,``,``,``,``,``,`cart`,``,``,``,``,`head`,``,14,0,0,0,1544766550),
	(13,0,1,`Kenika Suitters`,`Terms of Service`,``,`index,follow`,``,`tos`,``,``,``,``,``,``,`tos`,``,``,``,``,`footer`,`<p>The below Terms of Service is only an example of what you can dispay on your website.</p>
<h1>Terms of Service (\"Terms\")</h1>
<p>Last updated: June 26, 2018</p>
<p>Please read these Terms of Service (\"Terms\", \"Terms of Service\") carefully before using the https://diemen.design website (the \"Service\") operated by Diemen Design (\"us\", \"we\", or \"our\").</p>
<p>Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users and others who access or use the Service.</p>
<p>By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service. This Terms of Service agreement  for Diemen Design based on the Terms and Conditions from <a href=\"https://termsfeed.com/\">TermsFeed</a>.</p>
<h2>Accounts</h2>
<p>When you create an account with us, you must provide us information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.</p>
<p>You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password, whether your password is with our Service or a third-party service.</p>
<p>You agree not to disclose your password to any third party. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.</p>
<h2>Links To Other Web Sites</h2>
<p>Our Service may contain links to third-party web sites or services that are not owned or controlled by Diemen Design.</p>
<p>Diemen Design has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third party web sites or services. You further acknowledge and agree that Diemen Design shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such web sites or services.</p>
<p>We strongly advise you to read the terms and conditions and privacy policies of any third-party web sites or services that you visit.</p>
<h2>Termination</h2>
<p>We may terminate or suspend access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
<p>All provisions of the Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability.</p>
<p>We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
<p>Upon termination, your right to use the Service will immediately cease. If you wish to terminate your account, you may simply discontinue using the Service.</p>
<p>All provisions of the Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability.</p>
<h2>Governing Law</h2>
<p>These Terms shall be governed and construed in accordance with the laws of Tasmania, Australia, without regard to its conflict of law provisions.</p>
<p>Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect. These Terms constitute the entire agreement between us regarding our Service, and supersede and replace any prior agreements we might have between us regarding the Service.</p>
<h2>Changes</h2>
<p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.</p>
<p>By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using the Service.</p>
<h2>Contact Us</h2>
<p>If you have any questions about these Terms, please contact us.</p>`,10,1,56,0,1544766540),
	(14,0,1,`Kenika Suitters`,`Search`,``,`noindex`,``,`search`,``,``,``,``,``,``,`search`,``,``,``,``,`other`,``,8,1,140,0,1544766536),
	(15,0,1,`Kenika Suitters`,`About`,``,`index,follow`,``,`aboutus`,``,`https://picsum.photos/750/500?image=943`,``,``,``,``,`aboutus`,``,``,``,``,`head`,`<h1>The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king.</h1>
<p>We want a shrubbery!! I dunno. Must be a king. Bring her forward! What a strange person. Bring her forward!</p>
<p>Found them? In Mercia?! The coconut\'s tropical! Shut up! Will you shut up?! We shall say \'Ni\' again to you, if you do not appease us. On second thoughts, let\'s not go there. It is a silly place.</p>
<h2>Did you dress her up like this?</h2>
<p>Bring her forward! The swallow may fly south with the sun, and the house martin or the plover may seek warmer climes in winter, yet these are not strangers to our land. Ah, now we see the violence inherent in the system!</p>
<p>I am your king. The Knights Who Say Ni demand a sacrifice! Bloody Peasant! Shut up! Will you shut up?! I\'m not a witch.</p>
<h3>I have to push the pram a lot.</h3>
<p>Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Why? Well, what do you want? Shut up! We want a shrubbery!! And the hat. She\'s a witch!</p>
<p>Be quiet! He hasn\'t got shit all over him. Well, how\'d you become king, then? Burn her!</p>
<p>What a strange person. Well, Mercia\'s a temperate zone! The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king.</p>
<p>It\'s only a model. We want a shrubbery!! On second thoughts, let\'s not go there. It is a silly place. Why? Did you dress her up like this?</p>
<p>Bring her forward! Ah, now we see the violence inherent in the system! Well, we did do the nose. Burn her anyway! I\'m not a witch. Well, how\'d you become king, then?</p>
<p>He hasn\'t got shit all over him. Shut up! Will you shut up?! I don\'t want to talk to you no more, you empty-headed animal food trough water! I fart in your general direction! Your mother was a hamster and your father smelt of elderberries! Now leave before I am forced to taunt you a second time!</p>
<p>And this isn\'t my nose. This is a false one. Oh, ow! Now, look here, my good man. Ni! Ni! Ni! Ni! You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you!</p>
<p>Bloody Peasant! I am your king. Be quiet! Shut up! Will you shut up?! Where\'d you get the coconuts? Knights of Ni, we are but simple travelers who seek the enchanter who lives beyond these woods.</p>
<p>I am your king. …Are you suggesting that coconuts migrate? Listen. Strange women lying in ponds distributing swords is no basis for a system of government. Supreme executive power derives from a mandate from the masses, not from some farcical aquatic ceremony.</p>
<p>Who\'s that then? Burn her! What a strange person. Shh! Knights, I bid you welcome to your new home. Let us ride to Camelot! Oh! Come and see the violence inherent in the system! Help, help, I\'m being repressed!</p>
<p>…Are you suggesting that coconuts migrate? The Lady of the Lake, her arm clad in the purest shimmering samite, held aloft Excalibur from the bosom of the water, signifying by divine providence that I, Arthur, was to carry Excalibur. That is why I am your king.</p>
<p>Bring her forward! I have to push the pram a lot. Oh! Come and see the violence inherent in the system! Help, help, I\'m being repressed! You don\'t frighten us, English pig-dogs! Go and boil your bottoms, sons of a silly person! I blow my nose at you, so-called Ah-thoor Keeng, you and all your silly English K-n-n-n-n-n-n-n-niggits!</p>
<p>You can\'t expect to wield supreme power just \'cause some watery tart threw a sword at you! Found them? In Mercia?! The coconut\'s tropical! Where\'d you get the coconuts? Why? How do you know she is a witch?</p>`,1,1,47,0,1544766531),
	(16,0,1,`Kenika Suitters`,`Proofs`,`Proofs`,`noindex,nofollow`,``,`proofs`,``,``,``,``,``,``,`proofs`,``,``,``,``,`other`,``,11,1,0,0,1544766545),
	(17,0,1,`Kenika Suitters`,`Newsletters`,``,`index,follow`,``,`newsletters`,``,``,``,``,``,``,`newsletters`,``,``,``,``,`footer`,``,15,0,0,0,1544766551),
	(19,0,1,`Kenika Suitters`,`Distributors`,`Distributors`,``,``,`distributors`,``,``,``,``,``,``,`distributors`,``,``,``,``,`head`,``,16,0,0,0,1544766554),
	(20,0,1,`Kenika Suitters`,`Privacy Policy`,``,``,``,`page`,``,``,``,``,``,``,`page`,`Article`,``,``,``,`footer`,`<h1>Privacy Policy</h1>


<p>Effective date: November 30, 2018</p>


<p>Diemen Design (\"us\", \"we\", or \"our\") operates the https://diemen.design/ website (hereinafter referred to as the \"Service\").</p>

<p>This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy is managed by the  for Diemen Design is <a href=\"https://termsfeed.com/privacy-policy/generator/\">TermsFeed\'s Privacy Policy Generator</a>.</p>

<p>We use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, the terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from https://diemen.design/</p>

<h2>Definitions</h2>
<ul>
    <li>
        <p><strong>Service</strong></p>
                <p>Service is the https://diemen.design/ website operated by Diemen Design</p>
            </li>
    <li>
        <p><strong>Personal Data</strong></p>
        <p>Personal Data means data about a living individual who can be identified from those data (or from those and other information either in our possession or likely to come into our possession).</p>
    </li>
    <li>
        <p><strong>Usage Data</strong></p>
        <p>Usage Data is data collected automatically either generated by the use of the Service or from the Service infrastructure itself (for example, the duration of a page visit).</p>
    </li>
    <li>
        <p><strong>Cookies</strong></p>
        <p>Cookies are small files stored on your device (computer or mobile device).</p>
    </li>
</ul>

<h2>Information Collection and Use</h2>
<p>We collect several different types of information for various purposes to provide and improve our Service to you.</p>

<h3>Types of Data Collected</h3>

<h4>Personal Data</h4>
<p>While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (\"Personal Data\"). Personally identifiable information may include, but is not limited to:</p>

<ul>
<li>Email address</li><li>First name and last name</li><li>Phone number</li><li>Address, State, Province, ZIP/Postal code, City</li><li>Cookies and Usage Data</li>
</ul>

<h4>Usage Data</h4>

<p>We may also collect information how the Service is accessed and used (\"Usage Data\"). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.</p>

<h4>Tracking &amp; Cookies Data</h4>
<p>We use cookies and similar tracking technologies to track the activity on our Service and we hold certain information.</p>
<p>Cookies are files with a small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Other tracking technologies are also used such as beacons, tags and scripts to collect and track information and to improve and analyse our Service.</p>
<p>You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.</p>
<p>Examples of Cookies we use:</p>
<ul>
    <li><strong>Session Cookies.</strong> We use Session Cookies to operate our Service.</li>
    <li><strong>Preference Cookies.</strong> We use Preference Cookies to remember your preferences and various settings.</li>
    <li><strong>Security Cookies.</strong> We use Security Cookies for security purposes.</li>
</ul>

<h2>Use of Data</h2>
    
<p>Diemen Design uses the collected data for various purposes:</p>    
<ul>
    <li>To provide and maintain the Service</li>
    <li>To notify you about changes to our Service</li>
    <li>To allow you to participate in interactive features of our Service when you choose to do so</li>
    <li>To provide customer care and support</li>
    <li>To provide analysis or valuable information so that we can improve the Service</li>
    <li>To monitor the usage of the Service</li>
    <li>To detect, prevent and address technical issues</li>
</ul>

<h2>Transfer Of Data</h2>
<p>Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.</p>
<p>If you are located outside Australia and choose to provide information to us, please note that we transfer the data, including Personal Data, to Australia and process it there.</p>
<p>Your consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.</p>
<p>Diemen Design will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.</p>

<h2>Disclosure Of Data</h2>

<h3>Legal Requirements</h3>
<p>Diemen Design may disclose your Personal Data in the good faith belief that such action is necessary to:</p>
<ul>
    <li>To comply with a legal obligation</li>
    <li>To protect and defend the rights or property of Diemen Design</li>
    <li>To prevent or investigate possible wrongdoing in connection with the Service</li>
    <li>To protect the personal safety of users of the Service or the public</li>
    <li>To protect against legal liability</li>
</ul>

<p>As an European citizen, under GDPR, you have certain individual rights. You can learn more about these guides in the <a href=\"https://termsfeed.com/blog/gdpr/#Individual_Rights_Under_the_GDPR\">GDPR Guide</a>.</p>

<h2>Security of Data</h2>
<p>The security of your data is important to us but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.</p>

<h2>Service Providers</h2>
<p>We may employ third party companies and individuals to facilitate our Service (\"Service Providers\"), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.</p>
<p>These third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.</p>

 


<h2>Links to Other Sites</h2>
<p>Our Service may contain links to other sites that are not operated by us. If you click a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.</p>
<p>We have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.</p>


<h2>Children\'s Privacy</h2>
<p>Our Service does not address anyone under the age of 18 (\"Children\").</p>
<p>We do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Child has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.</p>


<h2>Changes to This Privacy Policy</h2>
<p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
<p>We will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the \"effective date\" at the top of this Privacy Policy.</p>
<p>You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.</p>


<h2>Contact Us</h2>
<p>If you have any questions about this Privacy Policy, please contact us:</p>
<ul>
            <li>By visiting this page on our website: https://diemen.design/contactus</li>
      
        </ul>`,18,1,23,0,1544766559);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `messages`;

CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `ip` varchar(32) COLLATE utf8_bin NOT NULL,
  `mid` text COLLATE utf8_bin NOT NULL,
  `rmid` bigint(20) NOT NULL,
  `folder` varchar(16) COLLATE utf8_bin NOT NULL,
  `to_email` varchar(255) COLLATE utf8_bin NOT NULL,
  `to_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `from_email` varchar(255) COLLATE utf8_bin NOT NULL,
  `from_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `from_business` tinytext COLLATE utf8_bin NOT NULL,
  `from_phone` tinytext COLLATE utf8_bin NOT NULL,
  `from_mobile` tinytext COLLATE utf8_bin NOT NULL,
  `from_address` tinytext COLLATE utf8_bin NOT NULL,
  `from_suburb` tinytext COLLATE utf8_bin NOT NULL,
  `from_city` tinytext COLLATE utf8_bin NOT NULL,
  `from_state` tinytext COLLATE utf8_bin NOT NULL,
  `from_postcode` tinytext COLLATE utf8_bin NOT NULL,
  `subject` tinytext COLLATE utf8_bin NOT NULL,
  `status` tinytext COLLATE utf8_bin NOT NULL,
  `starred` int(1) NOT NULL,
  `important` int(1) NOT NULL,
  `notes_raw` text COLLATE utf8_bin NOT NULL,
  `notes_raw_mime` tinytext COLLATE utf8_bin NOT NULL,
  `notes_html` text COLLATE utf8_bin NOT NULL,
  `notes_html_mime` tinytext COLLATE utf8_bin NOT NULL,
  `attachments` text COLLATE utf8_bin NOT NULL,
  `email_date` int(10) NOT NULL,
  `size` bigint(20) NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `messages` (id, uid, ip, mid, rmid, folder, to_email, to_name, from_email, from_name, from_business, from_phone, from_mobile, from_address, from_suburb, from_city, from_state, from_postcode, subject, status, starred, important, notes_raw, notes_raw_mime, notes_html, notes_html_mime, attachments, email_date, size, ti) VALUES
	(1,0,`127.0.0.1`,``,0,`INBOX`,`info@studiojunkyard.com`,`Default`,`dennis@studiojunkyard.com`,`Dennis Suitters`,``,``,``,``,``,``,``,``,`test`,`read`,0,0,`test message`,``,``,``,``,0,0,1549166946);

-- ------------------------------------------------ 

DROP TABLE IF EXISTS `orderitems`;

CREATE TABLE IF NOT EXISTS `orderitems` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `oid` bigint(20) unsigned NOT NULL,
  `iid` bigint(20) unsigned NOT NULL,
  `cid` bigint(20) NOT NULL,
  `title` varchar(60) COLLATE utf8_bin NOT NULL,
  `quantity` mediumint(9) unsigned NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8_bin NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- ------------------------------------------------ 

DROP TABLE IF EXISTS `orders`;

CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cid` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `contentType` varchar(16) COLLATE utf8_bin NOT NULL,
  `qid` varchar(20) COLLATE utf8_bin NOT NULL,
  `qid_ti` int(10) unsigned NOT NULL,
  `iid` varchar(20) COLLATE utf8_bin NOT NULL,
  `iid_ti` int(10) unsigned NOT NULL,
  `did` varchar(20) COLLATE utf8_bin NOT NULL,
  `did_ti` int(10) unsigned NOT NULL,
  `aid` varchar(20) COLLATE utf8_bin NOT NULL,
  `aid_ti` int(10) unsigned NOT NULL,
  `due_ti` int(10) unsigned NOT NULL,
  `rid` bigint(20) NOT NULL,
  `notes` text COLLATE utf8_bin NOT NULL,
  `status` varchar(16) COLLATE utf8_bin NOT NULL,
  `postage` int(4) NOT NULL,
  `recurring` int(1) NOT NULL,
  `ti` int(10) unsigned NOT NULL,
  `eti` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- ------------------------------------------------ 

DROP TABLE IF EXISTS `rewards`;

CREATE TABLE IF NOT EXISTS `rewards` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(16) COLLATE utf8_bin NOT NULL,
  `title` tinytext COLLATE utf8_bin NOT NULL,
  `method` int(1) NOT NULL,
  `value` int(4) NOT NULL,
  `quantity` int(4) NOT NULL,
  `tis` int(10) NOT NULL,
  `tie` int(10) NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- ------------------------------------------------ 

DROP TABLE IF EXISTS `subscribers`;

CREATE TABLE IF NOT EXISTS `subscribers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `hash` varchar(32) COLLATE utf8_bin NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- ------------------------------------------------ 

DROP TABLE IF EXISTS `suggestions`;

CREATE TABLE IF NOT EXISTS `suggestions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rid` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `t` tinytext COLLATE utf8_bin NOT NULL,
  `c` tinytext COLLATE utf8_bin NOT NULL,
  `notes` text COLLATE utf8_bin NOT NULL,
  `reason` text COLLATE utf8_bin NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



-- ------------------------------------------------ 

DROP TABLE IF EXISTS `tracker`;

CREATE TABLE IF NOT EXISTS `tracker` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) NOT NULL,
  `urlDest` varchar(255) COLLATE utf8_bin NOT NULL,
  `urlFrom` varchar(255) COLLATE utf8_bin NOT NULL,
  `userAgent` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip` varchar(15) COLLATE utf8_bin NOT NULL,
  `browser` varchar(32) COLLATE utf8_bin NOT NULL,
  `os` varchar(32) COLLATE utf8_bin NOT NULL,
  `sid` varchar(64) COLLATE utf8_bin NOT NULL,
  `ti` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1539 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `tracker` (id, pid, urlDest, urlFrom, userAgent, ip, browser, os, sid, ti) VALUES
	(1219,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936189),
	(1220,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936190),
	(1221,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936190),
	(1222,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936190),
	(1223,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936240),
	(1224,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936240),
	(1225,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936240),
	(1226,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936240),
	(1227,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936323),
	(1228,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936323),
	(1229,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936323),
	(1230,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936323),
	(1231,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936462),
	(1232,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936462),
	(1233,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936463),
	(1234,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`8ous18rfpgbuj9u214p8ltah1f`,1548936463),
	(1235,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936582),
	(1236,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936582),
	(1237,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936582),
	(1238,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936582),
	(1239,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936593),
	(1240,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936593),
	(1241,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936593),
	(1242,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936594),
	(1243,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936666),
	(1244,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936666),
	(1245,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936666),
	(1246,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936666),
	(1247,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936824),
	(1248,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936824),
	(1249,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936824),
	(1250,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936824),
	(1251,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936975),
	(1252,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936975),
	(1253,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936975),
	(1254,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548936976),
	(1255,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937003),
	(1256,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937003),
	(1257,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937004),
	(1258,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937004),
	(1259,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937048),
	(1260,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937048),
	(1261,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937048),
	(1262,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937048),
	(1263,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937098),
	(1264,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937098),
	(1265,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937098),
	(1266,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`8ous18rfpgbuj9u214p8ltah1f`,1548937098),
	(1267,0,`http://localhost/lCMS/core/images/ui-bg_glass_75_e6e6e6_1x400.png`,`http://localhost/lCMS/core/css/jquery-ui.min.css`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`qiv943ut7hdaf3h18mlkpmq0um`,1548940422),
	(1268,0,`http://localhost/lCMS/core/images/ui-bg_glass_65_ffffff_1x400.png`,`http://localhost/lCMS/core/css/jquery-ui.min.css`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`qiv943ut7hdaf3h18mlkpmq0um`,1548940423),
	(1269,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941102),
	(1270,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941102),
	(1271,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941102),
	(1272,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941102),
	(1273,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941129),
	(1274,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941129),
	(1275,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941129),
	(1276,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941129),
	(1277,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941193),
	(1278,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941193),
	(1279,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941193),
	(1280,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941193),
	(1281,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941202),
	(1282,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941202),
	(1283,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941202),
	(1284,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941202),
	(1285,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941262),
	(1286,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941262),
	(1287,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941262),
	(1288,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941262),
	(1289,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941267),
	(1290,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941267),
	(1291,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941267),
	(1292,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548941267),
	(1293,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548942102),
	(1294,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548942102),
	(1295,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548942102),
	(1296,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`qiv943ut7hdaf3h18mlkpmq0um`,1548942102),
	(1297,1,`http://localhost/lCMS/`,`http://localhost/`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548985738),
	(1298,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`eq601snb1o6r897ud4b2hla4vu`,1548986263),
	(1299,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`eq601snb1o6r897ud4b2hla4vu`,1548986263),
	(1300,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`eq601snb1o6r897ud4b2hla4vu`,1548986263),
	(1301,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30`,`::1`,`Mobile`,`Android`,`eq601snb1o6r897ud4b2hla4vu`,1548986263),
	(1302,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986370),
	(1303,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986371),
	(1304,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986371),
	(1305,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986371),
	(1306,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986384),
	(1307,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986384),
	(1308,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986384),
	(1309,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986501),
	(1310,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986501),
	(1311,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986501),
	(1312,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986622),
	(1313,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986622),
	(1314,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986622),
	(1315,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`eq601snb1o6r897ud4b2hla4vu`,1548986622),
	(1316,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991000),
	(1317,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991000),
	(1318,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991000),
	(1319,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991000),
	(1320,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991070),
	(1321,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991070),
	(1322,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991070),
	(1323,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991070),
	(1324,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991107),
	(1325,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991108),
	(1326,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991108),
	(1327,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991108),
	(1328,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991192),
	(1329,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991192),
	(1330,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991192),
	(1331,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991192),
	(1332,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991207),
	(1333,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991207),
	(1334,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991208),
	(1335,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991208),
	(1336,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991217),
	(1337,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991217),
	(1338,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991217),
	(1339,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991217),
	(1340,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991229),
	(1341,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991229),
	(1342,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991229),
	(1343,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991229),
	(1344,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991333),
	(1345,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991333),
	(1346,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991333),
	(1347,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991333),
	(1348,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991403),
	(1349,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991403),
	(1350,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991403),
	(1351,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991403),
	(1352,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991423),
	(1353,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991423),
	(1354,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991423),
	(1355,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991423),
	(1356,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991477),
	(1357,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991477),
	(1358,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991477),
	(1359,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548991477),
	(1360,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992027),
	(1361,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992027),
	(1362,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992027),
	(1363,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992027),
	(1364,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992077),
	(1365,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992077),
	(1366,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992077),
	(1367,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`vpgroua0f721fcgcc685ajj883`,1548992077),
	(1368,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995714),
	(1369,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995714),
	(1370,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995714),
	(1371,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995714),
	(1372,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995786),
	(1373,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995786),
	(1374,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995786),
	(1375,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995786),
	(1376,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995913),
	(1377,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995913),
	(1378,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995913),
	(1379,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995913),
	(1380,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995933),
	(1381,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995933),
	(1382,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995933),
	(1383,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`iugnog3fe9u5g67f0n585kfd0b`,1548995933),
	(1384,1,`http://localhost/lCMS/`,`http://localhost/`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`e84le39d4aru26eac0esenl3o0`,1549065634),
	(1385,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077713),
	(1386,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077713),
	(1387,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077713),
	(1388,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077713),
	(1389,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077781),
	(1390,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077781),
	(1391,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077781),
	(1392,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`1nnjv5vdn3ot40j2mbg9f6uac5`,1549077781),
	(1393,1,`http://localhost/lCMS/`,`http://localhost/`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549153308),
	(1394,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154477),
	(1395,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154477),
	(1396,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154477),
	(1397,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154477),
	(1398,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154499),
	(1399,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154499),
	(1400,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154499),
	(1401,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154499),
	(1402,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154509),
	(1403,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154509),
	(1404,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154509),
	(1405,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`nokiae6r2hc12m1j5skopi9nom`,1549154509),
	(1406,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157797),
	(1407,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157798),
	(1408,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157798),
	(1409,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157798),
	(1410,0,`http://localhost/lCMS/core/js/popper.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157806),
	(1411,0,`http://localhost/lCMS/core/js/bootstrap.bundle.min.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157806),
	(1412,0,`http://localhost/lCMS/core/js/summernote-lite.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157806),
	(1413,0,`http://localhost/lCMS/core/js/toastr.js.map`,``,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549157806),
	(1414,0,`http://localhost/lCMS/core/svg/libre-svg-black.svg`,`http://localhost/lCMS/core/css/style2-dark.css`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549158180),
	(1415,0,`http://localhost/lCMS/adminbookings`,`http://localhost/lCMS/admin/bookings/edit/35`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549158983),
	(1416,0,`http://localhost/lCMS/core/svg/libre-svg-black.svg`,`http://localhost/lCMS/core/css/style2-dark.css`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`jd816fu2oa2u665qklp9254md1`,1549159426),
	(1417,0,`http://localhost/lCMS/core/svg/libre-svg-black.svg`,`http://localhost/lCMS/core/css/style2-dark.css`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`uv4i8k1bfab1sunj3i0brmsd1q`,1549166015),
	(1418,1,`http://localhost/lCMS/`,`http://localhost/`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`uv4i8k1bfab1sunj3i0brmsd1q`,1549166396),
	(1419,11,`http://localhost/lCMS/contactus`,`http://localhost/lCMS/`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`uv4i8k1bfab1sunj3i0brmsd1q`,1549166928),
	(1420,1,`http://localhost/lCMS/`,`http://localhost/`,`Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36`,`::1`,`Chrome`,`Linux`,`lr3vbifo67524oe2c8e37bt7dn`,1549246368),
	(1421,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`c35v4bpmfsgp1gk4e988i3a5qs`,1549264536),
	(1422,0,`http://localhost/lCMS/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264540),
	(1423,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264540),
	(1424,0,`http://localhost/lCMS/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264540),
	(1425,0,`http://localhost/lCMS/lpt9`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264542),
	(1426,0,`http://localhost/lCMS/~nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264542),
	(1427,0,`http://localhost/lCMS/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264542),
	(1428,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264543),
	(1429,14,`http://localhost/lCMS/search`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1430,0,`http://localhost/lCMS/http:/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1431,0,`http://localhost/lCMS/login/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1432,9,`http://localhost/lCMS/service`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1433,0,`http://localhost/lCMS/sitemap`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1434,7,`http://localhost/lCMS/testimonials`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1435,11,`http://localhost/lCMS/contactus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1436,13,`http://localhost/lCMS/tos`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1437,15,`http://localhost/lCMS/aboutus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1438,3,`http://localhost/lCMS/portfolio`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1439,0,`http://localhost/lCMS/error/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1440,2,`http://localhost/lCMS/article`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1441,4,`http://localhost/lCMS/bookings`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1442,0,`http://localhost/lCMS/page/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1443,14,`http://localhost/lCMS/search/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1444,14,`http://localhost/lCMS/search/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1445,0,`http://localhost/lCMS/core/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264544),
	(1446,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264545),
	(1447,0,`http://localhost/lCMS/layout/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264545),
	(1448,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264545),
	(1449,0,`http://localhost/lCMS/sitemap/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1450,0,`http://localhost/lCMS/sitemap/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1451,0,`http://localhost/lCMS/crossdomain.xml`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1452,0,`http://localhost/lCMS/bogus%0DVega-Inject:bogus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1453,0,`http://localhost/lCMS/bogus%0AVega-Inject:bogus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1454,1,`http://localhost/lCMS/`,``,`() { :; }; printf \'Content-Type: text/json\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1455,7,`http://localhost/lCMS/testimonials/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1456,7,`http://localhost/lCMS/testimonials/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1457,11,`http://localhost/lCMS/contactus/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1458,11,`http://localhost/lCMS/contactus/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1459,13,`http://localhost/lCMS/tos/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1460,13,`http://localhost/lCMS/tos/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1461,0,`http://localhost/lCMS/()%20{%20:%3B%20}%3B%20printf%20\'Content-Type:%20text/json\\r\\n\\r\\n%25s%20vulnerable%20%25s\'%20\'VEGA123\'%20\'VEGA123\'`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1462,9,`http://localhost/lCMS/service/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1463,9,`http://localhost/lCMS/service/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1464,0,`http://localhost/lCMS/crossdomain.xml`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1465,0,`http://localhost/lCMS/bogus%0AVega-Inject:bogus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1466,0,`http://localhost/lCMS/bogus%0DVega-Inject:bogus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1467,1,`http://localhost/lCMS/`,``,`() { :; }; printf \'Content-Type: text/json\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1468,0,`http://localhost/lCMS/login/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264546),
	(1469,1,`http://localhost/lCMS/`,`() { :; }; printf \'Content-Type: text/json\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'`,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1470,0,`http://localhost/lCMS/()%20{%20:%3B%20}%3B%20printf%20\'Content-Type:%20text/json\\r\\n\\r\\n%25s%20vulnerable%20%25s\'%20\'VEGA123\'%20\'VEGA123\'`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1471,0,`http://localhost/lCMS/http:/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1472,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1473,0,`http://localhost/lCMS/http:?_test1=ccddeeeimmnossstwwxy.:\\\\\\&_test2=acdepsstw//&_test3=bhins//&_test4=CEEFLMORSTeeinnnosttx-*&_test5=cefhilnosu///&_test6=acceiilpprrrssttt1)(&_test7=aaaceijlprrsttv1):(`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1474,0,`http://localhost/lCMS/http:?_test1=c:\\windows\\system32\\cmd.exe&_test2=/etc/passwd&_test3=|/bin/sh&_test4=(SELECT%20*%20FROM%20nonexistent)%20--&_test5=>/no/such/file&_test6=<script>alert(1)</script>&_test7=javascript:alert(1)`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1475,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1476,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`df69e47h2bu0qtvkt8u9d806ee`,1549264547),
	(1477,0,`http://localhost/lCMS/http:`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`5skqn77a0apbj3hdkb7b5q7e7l`,1549264547),
	(1478,0,`http://localhost/lCMS/http:`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`df69e47h2bu0qtvkt8u9d806ee`,1549264547),
	(1479,0,`http://localhost/lCMS/http:/localhost/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`df69e47h2bu0qtvkt8u9d806ee`,1549264547),
	(1480,0,`http://localhost/lCMS/http:/`,``,`() { :; }; printf \'Content-Type: text/json\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`df69e47h2bu0qtvkt8u9d806ee`,1549264548),
	(1481,1,`http://localhost/lCMS/`,``,`() { _; } >_[$($())] { printf \'Content-Type: text/html\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'; }`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`df69e47h2bu0qtvkt8u9d806ee`,1549264548),
	(1482,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1483,0,`http://localhost/lCMS/http:/()%20{%20:%3B%20}%3B%20printf%20\'Content-Type:%20text/json\\r\\n\\r\\n%25s%20vulnerable%20%25s\'%20\'VEGA123\'%20\'VEGA123\'`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`df69e47h2bu0qtvkt8u9d806ee`,1549264548),
	(1484,0,`http://localhost/lCMS/http:/crossdomain.xml`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1485,0,`http://localhost/lCMS/http:/bogus%0DVega-Inject:bogus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1486,0,`http://localhost/lCMS/http:/bogus%0AVega-Inject:bogus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1487,0,`http://localhost/lCMS/http:`,`() { :; }; printf \'Content-Type: text/json\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'`,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1488,1,`http://localhost/lCMS/`,``,`() { _; } >_[$($())] { printf \'Content-Type: text/html\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'; }`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1489,0,`http://localhost/lCMS/()%20{%20_%3B%20}%20>_[%24(%24())]%20{%20printf%20\'Content-Type:%20text/html\\r\\n\\r\\n%25s%20vulnerable%20%25s\'%20\'VEGA123\'%20\'VEGA123\'%3B%20}`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1490,0,`http://localhost/lCMS/http:`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1491,0,`http://localhost/lCMS/()%20{%20_%3B%20}%20>_[%24(%24())]%20{%20printf%20\'Content-Type:%20text/html\\r\\n\\r\\n%25s%20vulnerable%20%25s\'%20\'VEGA123\'%20\'VEGA123\'%3B%20}`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tfipt4f6kmrcq2ffr36v6l84ra`,1549264548),
	(1492,0,`http://localhost/lCMS/http:`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`d1b8mscpm809mgiufc6ae4sb9k`,1549264548),
	(1493,1,`http://localhost/lCMS/`,`() { _; } >_[$($())] { printf \'Content-Type: text/html\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'; }`,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`d1b8mscpm809mgiufc6ae4sb9k`,1549264548),
	(1494,0,`http://localhost/lCMS/http:`,``,`() { _; } >_[$($())] { printf \'Content-Type: text/html\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'; }`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`d1b8mscpm809mgiufc6ae4sb9k`,1549264548),
	(1495,1,`http://localhost/lCMS/`,`() { _; } >_[$($())] { printf \'Content-Type: text/html\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'; }`,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`d1b8mscpm809mgiufc6ae4sb9k`,1549264548),
	(1496,0,`http://localhost/lCMS/http:/()%20{%20_%3B%20}%20>_[%24(%24())]%20{%20printf%20\'Content-Type:%20text/html\\r\\n\\r\\n%25s%20vulnerable%20%25s\'%20\'VEGA123\'%20\'VEGA123\'%3B%20}`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`d1b8mscpm809mgiufc6ae4sb9k`,1549264548),
	(1497,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`d1b8mscpm809mgiufc6ae4sb9k`,1549264548),
	(1498,0,`http://localhost/lCMS/http:`,`() { _; } >_[$($())] { printf \'Content-Type: text/html\\r\\n\\r\\n%s vulnerable %s\' \'VEGA123\' \'VEGA123\'; }`,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`d1b8mscpm809mgiufc6ae4sb9k`,1549264548),
	(1499,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`chn0d6mrdfafoeh8d265m9hdba`,1549264548),
	(1500,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`ukc4kklrl7ujacc8sphv7hpqh6`,1549264548),
	(1501,0,`http://localhost/lCMS/http:`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`chn0d6mrdfafoeh8d265m9hdba`,1549264548),
	(1502,0,`http://localhost/lCMS/()%20{%20:%3B}%3B%20/bin/sleep%2031`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`ukc4kklrl7ujacc8sphv7hpqh6`,1549264549),
	(1503,0,`http://localhost/lCMS/http:`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lsk9pi6u54daotok5mv0ieie0s`,1549264549),
	(1504,1,`http://localhost/lCMS/`,``,`() { :;}; /bin/sleep 31`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`ukc4kklrl7ujacc8sphv7hpqh6`,1549264549),
	(1505,1,`http://localhost/lCMS/`,``,`() { :;}; /bin/sleep 31`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lsk9pi6u54daotok5mv0ieie0s`,1549264549),
	(1506,0,`http://localhost/lCMS/http:/()%20{%20:%3B}%3B%20/bin/sleep%2031`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lsk9pi6u54daotok5mv0ieie0s`,1549264549),
	(1507,1,`http://localhost/lCMS/`,`() { :;}; /bin/sleep 31`,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lsk9pi6u54daotok5mv0ieie0s`,1549264549),
	(1508,0,`http://localhost/lCMS/http:`,``,`() { :;}; /bin/sleep 31`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lsk9pi6u54daotok5mv0ieie0s`,1549264549),
	(1509,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lsk9pi6u54daotok5mv0ieie0s`,1549264549),
	(1510,0,`http://localhost/lCMS/http:`,`() { :;}; /bin/sleep 31`,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lsk9pi6u54daotok5mv0ieie0s`,1549264549),
	(1511,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tj465nev2m2ck017qtdlei2l3s`,1549264549),
	(1512,1,`http://localhost/lCMS/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`lj7u18g3m40i7b6dnjlu87md4p`,1549264549),
	(1513,0,`http://localhost/lCMS/page/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`tj465nev2m2ck017qtdlei2l3s`,1549264549),
	(1514,0,`http://localhost/lCMS/http:`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264549),
	(1515,4,`http://localhost/lCMS/bookings/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264549),
	(1516,4,`http://localhost/lCMS/bookings/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264549),
	(1517,2,`http://localhost/lCMS/article/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264550),
	(1518,2,`http://localhost/lCMS/article/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264550),
	(1519,0,`http://localhost/lCMS/error/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264550),
	(1520,3,`http://localhost/lCMS/portfolio/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264550),
	(1521,3,`http://localhost/lCMS/portfolio/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264550),
	(1522,15,`http://localhost/lCMS/aboutus/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264550),
	(1523,15,`http://localhost/lCMS/aboutus/abc123/`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264550),
	(1524,14,`http://localhost/lCMS/search/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264551),
	(1525,0,`http://localhost/lCMS/core/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264552),
	(1526,0,`http://localhost/lCMS/core/~nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264552),
	(1527,0,`http://localhost/lCMS/core/lpt9`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264552),
	(1528,0,`http://localhost/lCMS/layout/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264552),
	(1529,0,`http://localhost/lCMS/layout/~nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264552),
	(1530,0,`http://localhost/lCMS/layout/lpt9`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264552),
	(1531,13,`http://localhost/lCMS/tos/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264552),
	(1532,0,`http://localhost/lCMS/http:/localhost/nosuchpage123`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264553),
	(1533,11,`http://localhost/lCMS/contactus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264563),
	(1534,7,`http://localhost/lCMS/testimonials`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264563),
	(1535,11,`http://localhost/lCMS/contactus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264563),
	(1536,7,`http://localhost/lCMS/testimonials`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264564),
	(1537,11,`http://localhost/lCMS/contactus`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264564),
	(1538,0,`http://localhost/lCMS/PUT-putfile`,``,`UserAgent`,`127.0.0.1`,`Unknown Browser`,`Unknown OS Platform`,`cti9t5633ogi8qek9s5tj3tgku`,1549264564);

-- ------------------------------------------------ 

